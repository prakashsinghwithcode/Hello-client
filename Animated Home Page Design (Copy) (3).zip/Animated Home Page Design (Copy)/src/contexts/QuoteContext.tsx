import { createContext, useContext, useState, ReactNode } from "react";

interface QuoteContextType {
  isQuoteMode: boolean;
  selectedService: string;
  setQuoteMode: (isQuote: boolean, service?: string) => void;
  resetQuoteMode: () => void;
}

const QuoteContext = createContext<QuoteContextType | undefined>(undefined);

export function QuoteProvider({ children }: { children: ReactNode }) {
  const [isQuoteMode, setIsQuoteMode] = useState(false);
  const [selectedService, setSelectedService] = useState("");

  const setQuoteMode = (isQuote: boolean, service: string = "") => {
    setIsQuoteMode(isQuote);
    setSelectedService(service);
  };

  const resetQuoteMode = () => {
    setIsQuoteMode(false);
    setSelectedService("");
  };

  return (
    <QuoteContext.Provider
      value={{ isQuoteMode, selectedService, setQuoteMode, resetQuoteMode }}
    >
      {children}
    </QuoteContext.Provider>
  );
}

export function useQuote() {
  const context = useContext(QuoteContext);
  if (context === undefined) {
    throw new Error("useQuote must be used within a QuoteProvider");
  }
  return context;
}
