import { createContext, useContext, useState, ReactNode } from "react";

interface ConsultationContextType {
  showConsultation: boolean;
  openConsultation: () => void;
  closeConsultation: () => void;
  setConsultationOpen: (value: boolean) => void;
}

const ConsultationContext = createContext<ConsultationContextType | undefined>(undefined);

export function ConsultationProvider({ children }: { children: ReactNode }) {
  const [showConsultation, setShowConsultation] = useState(false);

  const openConsultation = () => setShowConsultation(true);
  const closeConsultation = () => setShowConsultation(false);
  const setConsultationOpen = (value: boolean) => setShowConsultation(value);

  return (
    <ConsultationContext.Provider value={{ showConsultation, openConsultation, closeConsultation, setConsultationOpen }}>
      {children}
    </ConsultationContext.Provider>
  );
}

export function useConsultation() {
  const context = useContext(ConsultationContext);
  if (context === undefined) {
    throw new Error("useConsultation must be used within a ConsultationProvider");
  }
  return context;
}