import { motion } from "motion/react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Target, Eye } from "lucide-react";

export function MissionVision() {
  const { t } = useLanguage();

  const cards = [
    {
      icon: Target,
      title: t('about.mission.title'),
      description: t('about.mission.description'),
      gradient: "from-blue-500 to-purple-500",
      delay: 0,
      direction: -50,
    },
    {
      icon: Eye,
      title: t('about.vision.title'),
      description: t('about.vision.description'),
      gradient: "from-purple-500 to-cyan-500",
      delay: 0.2,
      direction: 50,
    },
  ];

  return (
    <section className="relative py-32 bg-gradient-to-br from-blue-50/30 via-white to-purple-50/30 overflow-hidden">
      {/* Background Decorations */}
      <motion.div
        className="absolute top-20 right-10 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{
          background: "linear-gradient(135deg, rgb(6, 182, 212), rgb(147, 51, 234))",
        }}
        animate={{
          scale: [1, 1.3, 1],
          rotate: [0, 90, 0],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl font-black">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('about.missionVision.heading')}
            </span>
          </h2>
        </motion.div>

        {/* Cards Grid */}
        <div className="grid lg:grid-cols-2 gap-8">
          {cards.map((card, index) => {
            const Icon = card.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: card.direction }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.8, delay: card.delay }}
                whileHover={{ y: -10 }}
                className="relative group"
              >
                {/* Glow Effect on Hover */}
                <div
                  className={`absolute -inset-1 bg-gradient-to-r ${card.gradient} rounded-3xl opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-500`}
                />

                {/* Card */}
                <div className="relative bg-white p-10 md:p-12 rounded-3xl border border-gray-100 shadow-xl">
                  {/* Icon */}
                  <motion.div
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                    className={`w-20 h-20 rounded-2xl bg-gradient-to-r ${card.gradient} flex items-center justify-center mb-6 shadow-lg`}
                  >
                    <Icon className="w-10 h-10 text-white" />
                  </motion.div>

                  {/* Title */}
                  <h3 className="text-3xl md:text-4xl font-black mb-6 text-gray-900">
                    {card.title}
                  </h3>

                  {/* Description */}
                  <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
                    {card.description}
                  </p>

                  {/* Bottom Accent Line */}
                  <motion.div
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: card.delay + 0.3 }}
                    className={`mt-8 h-1 bg-gradient-to-r ${card.gradient} rounded-full`}
                    style={{ transformOrigin: "left" }}
                  />

                  {/* Micro Animation on Hover */}
                  <motion.div
                    className="absolute top-6 right-6 w-3 h-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-500"
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 1, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                    }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
