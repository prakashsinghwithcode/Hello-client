import { motion, useInView, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Code, Palette, TrendingUp, Users, Sparkles } from "lucide-react";

export function TeamCulture() {
  const ref = useRef(null);
  const { t } = useLanguage();
  const isInView = useInView(ref, { once: true, amount: 0.2 });
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-50, 50]);

  const teamCards = [
    {
      id: 1,
      icon: Code,
      title: t('about.team.dev'),
      description: t('about.team.devDesc'),
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      id: 2,
      icon: Palette,
      title: t('about.team.design'),
      description: t('about.team.designDesc'),
      gradient: "from-purple-500 to-pink-500",
    },
    {
      id: 3,
      icon: TrendingUp,
      title: t('about.team.marketing'),
      description: t('about.team.marketingDesc'),
      gradient: "from-cyan-500 to-blue-500",
    },
    {
      id: 4,
      icon: Users,
      title: t('about.team.strategy'),
      description: t('about.team.strategyDesc'),
      gradient: "from-green-500 to-cyan-500",
    },
  ];

  return (
    <section className="relative py-32 bg-white overflow-hidden" ref={ref} style={{ position: 'relative' }}>
      {/* Parallax Background Elements */}
      <motion.div
        className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-3xl"
        style={{ y }}
      />
      <motion.div
        className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-br from-cyan-500/10 to-blue-500/10 rounded-full blur-3xl"
        style={{ y: y2 }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-block px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full mb-6"
          >
            <Sparkles className="inline w-4 h-4 mr-2" />
            {t('about.team.badge')}
          </motion.div>

          <h2 className="text-5xl md:text-6xl font-black mb-6">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('about.team.title')}
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-700 max-w-3xl mx-auto leading-relaxed">
            {t('about.team.subtitle')}
          </p>
        </motion.div>

        {/* Team Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {teamCards.map((card, index) => {
            const Icon = card.icon;

            return (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="relative group"
              >
                {/* Hover Glow */}
                <div
                  className={`absolute -inset-1 bg-gradient-to-r ${card.gradient} rounded-3xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500`}
                />

                <div className="relative bg-gradient-to-br from-white to-gray-50 p-8 rounded-3xl shadow-lg border border-gray-100 text-center">
                  <motion.div
                    className={`w-20 h-20 bg-gradient-to-r ${card.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg`}
                    initial={{ scale: 0, rotate: -180 }}
                    animate={isInView ? { scale: 1, rotate: 0 } : {}}
                    transition={{
                      duration: 0.6,
                      delay: index * 0.1 + 0.2,
                      type: "spring",
                      bounce: 0.5,
                    }}
                    whileHover={{ rotate: 360 }}
                  >
                    <Icon className="w-10 h-10 text-white" />
                  </motion.div>

                  <h3 className="text-2xl font-bold mb-2 text-gray-900">
                    {card.title}
                  </h3>
                  <p className="text-gray-600">{card.description}</p>

                  {/* Animated Dot */}
                  <motion.div
                    className={`absolute top-4 right-4 w-2 h-2 rounded-full bg-gradient-to-r ${card.gradient}`}
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 1, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: index * 0.3,
                    }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Culture Statement */}
        <motion.div
          className="bg-gradient-to-r from-blue-500/5 via-purple-500/5 to-cyan-500/5 p-12 md:p-16 rounded-3xl border border-purple-200 shadow-xl"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <div className="text-center max-w-4xl mx-auto">
            <motion.h3
              className="text-3xl md:text-4xl font-black mb-6 text-gray-900"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.7 }}
            >
              {t('about.team.cultureTitle')}
            </motion.h3>

            <motion.p
              className="text-xl md:text-2xl text-gray-700 leading-relaxed mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.8 }}
            >
              {t('about.team.cultureText')}
            </motion.p>

            <motion.div
              className="flex flex-wrap justify-center gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.9 }}
            >
              {[
                t('about.team.value1'),
                t('about.team.value2'),
                t('about.team.value3'),
                t('about.team.value4'),
                t('about.team.value5'),
              ].map((value, index) => (
                <motion.span
                  key={index}
                  className="px-6 py-3 bg-white rounded-full font-semibold shadow-md"
                  style={{
                    background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                  whileHover={{ scale: 1.1, boxShadow: "0 10px 25px rgba(79, 70, 229, 0.2)" }}
                  initial={{ opacity: 0, scale: 0 }}
                  animate={isInView ? { opacity: 1, scale: 1 } : {}}
                  transition={{ delay: 0.9 + index * 0.1 }}
                >
                  {value}
                </motion.span>
              ))}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}