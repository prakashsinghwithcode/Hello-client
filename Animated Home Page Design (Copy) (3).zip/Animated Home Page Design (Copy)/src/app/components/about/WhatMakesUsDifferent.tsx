import { motion } from "motion/react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Users, Zap, DollarSign, MessageCircle, Layers, Heart } from "lucide-react";

export function WhatMakesUsDifferent() {
  const { t } = useLanguage();

  const features = [
    {
      icon: Users,
      title: t('about.different.point1'),
      gradient: "from-blue-500 to-purple-500",
    },
    {
      icon: Zap,
      title: t('about.different.point2'),
      gradient: "from-purple-500 to-pink-500",
    },
    {
      icon: Zap,
      title: t('about.different.point3'),
      gradient: "from-cyan-500 to-blue-500",
    },
    {
      icon: DollarSign,
      title: t('about.different.point4'),
      gradient: "from-green-500 to-cyan-500",
    },
    {
      icon: Layers,
      title: t('about.different.point5'),
      gradient: "from-purple-500 to-blue-500",
    },
    {
      icon: Heart,
      title: t('about.different.point6'),
      gradient: "from-pink-500 to-purple-500",
    },
  ];

  return (
    <section className="relative py-32 bg-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, rgb(79, 70, 229) 1px, transparent 0)`,
            backgroundSize: "40px 40px",
          }}
        />
      </div>

      {/* Floating Gradient Orb */}
      <motion.div
        className="absolute top-1/3 right-0 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{
          background: "linear-gradient(135deg, rgb(147, 51, 234), rgb(6, 182, 212))",
        }}
        animate={{
          scale: [1, 1.4, 1],
          x: [0, -50, 0],
        }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-block px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full mb-6"
          >
            {t('about.different.badge')}
          </motion.div>

          <h2 className="text-5xl md:text-6xl font-black mb-6">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('about.different.title')}
            </span>
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('about.different.subtitle')}
          </p>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.1,
                  type: "spring",
                  bounce: 0.4,
                }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="relative group"
              >
                {/* Glow Effect */}
                <div
                  className={`absolute -inset-1 bg-gradient-to-r ${feature.gradient} rounded-2xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500`}
                />

                {/* Card */}
                <div className="relative bg-gradient-to-br from-white to-gray-50 p-8 rounded-2xl border border-gray-100 shadow-lg">
                  {/* Icon with Pop Animation */}
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.6,
                      delay: index * 0.1 + 0.2,
                      type: "spring",
                      bounce: 0.5,
                    }}
                    whileHover={{ rotate: 360 }}
                    className={`w-16 h-16 rounded-xl bg-gradient-to-r ${feature.gradient} flex items-center justify-center mb-6 shadow-lg`}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-gray-900 leading-tight">
                    {feature.title}
                  </h3>

                  {/* Decorative Corner Dot */}
                  <motion.div
                    className={`absolute top-4 right-4 w-2 h-2 rounded-full bg-gradient-to-r ${feature.gradient}`}
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 1, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: index * 0.2,
                    }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom Statement */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-20 text-center"
        >
          <div className="inline-block px-10 py-6 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-cyan-500/10 rounded-3xl border border-purple-200 shadow-lg">
            <p className="text-xl md:text-2xl font-bold text-gray-800">
              {t('about.different.bottomText')}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
