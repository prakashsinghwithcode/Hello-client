import { motion } from "motion/react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Sparkles } from "lucide-react";

export function AboutHero() {
  const { t } = useLanguage();

  const words = t('about.hero.title').split(' ');

  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden bg-gradient-to-br from-white via-blue-50/30 to-purple-50/30">
      {/* Animated Background Orbs */}
      <motion.div
        className="absolute top-20 left-10 w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{
          background: "linear-gradient(135deg, rgb(59, 130, 246), rgb(147, 51, 234))",
        }}
        animate={{
          scale: [1, 1.3, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{
          background: "linear-gradient(135deg, rgb(6, 182, 212), rgb(79, 70, 229))",
        }}
        animate={{
          scale: [1, 1.4, 1],
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{ duration: 25, repeat: Infinity, ease: "easeInOut", delay: 2 }}
      />

      {/* Grid Pattern */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `radial-gradient(circle at 2px 2px, rgb(79, 70, 229) 1px, transparent 0)`,
            backgroundSize: "40px 40px",
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Text Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full mb-6"
            >
              <Sparkles className="w-4 h-4" />
              {t('about.hero.badge')}
            </motion.div>

            {/* Animated Title - Word by Word Reveal */}
            <h1 className="text-5xl md:text-7xl font-black mb-6 leading-tight">
              {words.map((word, index) => (
                <motion.span
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.5,
                    delay: 0.4 + index * 0.1,
                    ease: "easeOut",
                  }}
                  className="inline-block mr-3"
                >
                  {index === words.length - 1 ? (
                    <span
                      className="bg-clip-text text-transparent"
                      style={{
                        backgroundImage:
                          "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
                      }}
                    >
                      {word}
                    </span>
                  ) : (
                    <span className="text-gray-900">{word}</span>
                  )}
                </motion.span>
              ))}
            </h1>

            {/* Subtext */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="text-xl md:text-2xl text-gray-600 leading-relaxed mb-8"
            >
              {t('about.hero.subtext')}
            </motion.p>

            {/* Stats Bar */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.2 }}
              className="flex flex-wrap gap-8"
            >
              {[
                { label: t('about.hero.stat1'), value: "100+" },
                { label: t('about.hero.stat2'), value: "50+" },
                { label: t('about.hero.stat3'), value: "24/7" },
              ].map((stat, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="text-center"
                >
                  <div
                    className="text-3xl md:text-4xl font-black bg-clip-text text-transparent"
                    style={{
                      backgroundImage:
                        "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                    }}
                  >
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600 font-semibold">
                    {stat.label}
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right: Abstract Visual */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative"
          >
            {/* Floating Gradient Cards */}
            <div className="relative h-[500px] flex items-center justify-center">
              {/* Background Card */}
              <motion.div
                className="absolute w-80 h-80 rounded-3xl"
                style={{
                  background:
                    "linear-gradient(135deg, rgba(79, 70, 229, 0.1), rgba(147, 51, 234, 0.1))",
                }}
                animate={{
                  rotate: [0, 5, 0],
                  scale: [1, 1.05, 1],
                }}
                transition={{
                  duration: 6,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />

              {/* Middle Card */}
              <motion.div
                className="absolute w-72 h-72 rounded-3xl border-4 border-white shadow-2xl"
                style={{
                  background:
                    "linear-gradient(135deg, rgb(147, 51, 234), rgb(6, 182, 212))",
                }}
                animate={{
                  rotate: [0, -5, 0],
                  y: [0, -20, 0],
                }}
                transition={{
                  duration: 8,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.5,
                }}
              />

              {/* Front Card */}
              <motion.div
                className="absolute w-64 h-64 rounded-3xl border-4 border-white shadow-2xl flex items-center justify-center"
                style={{
                  background:
                    "linear-gradient(135deg, rgb(59, 130, 246), rgb(147, 51, 234))",
                }}
                animate={{
                  rotate: [0, 10, 0],
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 1,
                }}
              >
                <div className="text-center text-white">
                  <Sparkles className="w-16 h-16 mx-auto mb-4" />
                  <div className="text-2xl font-black">
                    {t('about.hero.visualText')}
                  </div>
                </div>
              </motion.div>

              {/* Floating Particles */}
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute w-3 h-3 rounded-full"
                  style={{
                    background:
                      "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                    left: `${20 + i * 15}%`,
                    top: `${10 + i * 10}%`,
                  }}
                  animate={{
                    y: [0, -30, 0],
                    opacity: [0.3, 1, 0.3],
                  }}
                  transition={{
                    duration: 3 + i,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: i * 0.3,
                  }}
                />
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1.5 }}
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="w-6 h-10 border-2 border-gray-400 rounded-full flex items-start justify-center p-2"
        >
          <motion.div
            animate={{ y: [0, 12, 0], opacity: [1, 0, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="w-1.5 h-1.5 bg-gray-600 rounded-full"
          />
        </motion.div>
      </motion.div>
    </section>
  );
}
