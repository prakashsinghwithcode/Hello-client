import { motion } from "motion/react";
import { useLanguage } from "@/contexts/LanguageContext";
import { BookOpen, Users, Target, Sparkles } from "lucide-react";

export function OurStory() {
  const { t } = useLanguage();

  const paragraphs = [
    {
      icon: Target,
      text: t('about.story.para1'),
      delay: 0.2,
    },
    {
      icon: Users,
      text: t('about.story.para2'),
      delay: 0.4,
    },
    {
      icon: Sparkles,
      text: t('about.story.para3'),
      delay: 0.6,
    },
  ];

  return (
    <section className="relative py-32 bg-white overflow-hidden">
      {/* Background Elements */}
      <motion.div
        className="absolute top-1/4 left-0 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{
          background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
        }}
        animate={{
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="max-w-6xl mx-auto px-4 md:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full mb-6"
          >
            <BookOpen className="w-4 h-4" />
            {t('about.story.badge')}
          </motion.div>

          <h2 className="text-5xl md:text-6xl font-black mb-6">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('about.story.title')}
            </span>
          </h2>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical Line */}
          <motion.div
            className="absolute left-8 top-0 w-1 bg-gradient-to-b from-blue-500 via-purple-500 to-cyan-500 rounded-full"
            initial={{ height: 0 }}
            whileInView={{ height: "100%" }}
            viewport={{ once: true }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
          />

          {/* Story Paragraphs */}
          <div className="space-y-16">
            {paragraphs.map((para, index) => {
              const Icon = para.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{ duration: 0.8, delay: para.delay }}
                  className="relative pl-24"
                >
                  {/* Icon Circle */}
                  <motion.div
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.6,
                      delay: para.delay + 0.3,
                      type: "spring",
                      bounce: 0.5,
                    }}
                    className="absolute left-0 w-16 h-16 rounded-full flex items-center justify-center border-4 border-white shadow-xl"
                    style={{
                      background:
                        "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                    }}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Content Card */}
                  <motion.div
                    whileHover={{ scale: 1.02, x: 5 }}
                    className="bg-gradient-to-br from-gray-50 to-blue-50/30 p-8 rounded-3xl border border-gray-100 shadow-lg"
                  >
                    <p className="text-lg md:text-xl text-gray-700 leading-relaxed">
                      {para.text}
                    </p>
                  </motion.div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom Decoration */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-20 text-center"
        >
          <div className="inline-block px-8 py-4 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-cyan-500/10 rounded-full border border-purple-200">
            <p className="text-lg font-semibold text-gray-800">
              {t('about.story.tagline')}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
