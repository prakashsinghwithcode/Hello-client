import { motion, useInView } from "motion/react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useRef, useState, useEffect } from "react";
import { Award, Users, MapPin, Briefcase } from "lucide-react";

function Counter({ end, duration = 2, suffix = "" }: { end: number; duration?: number; suffix?: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const increment = end / (duration * 60);
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, 1000 / 60);

      return () => clearInterval(timer);
    }
  }, [isInView, end, duration]);

  return (
    <span ref={ref}>
      {count}
      {suffix}
    </span>
  );
}

export function TrustSection() {
  const { t } = useLanguage();

  const stats = [
    {
      icon: Briefcase,
      value: 100,
      suffix: "+",
      label: t('about.trust.stat1'),
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      icon: Users,
      value: 50,
      suffix: "+",
      label: t('about.trust.stat2'),
      gradient: "from-purple-500 to-pink-500",
    },
    {
      icon: MapPin,
      value: 24,
      suffix: "/7",
      label: t('about.trust.stat3'),
      gradient: "from-cyan-500 to-blue-500",
    },
    {
      icon: Award,
      value: 100,
      suffix: "%",
      label: t('about.trust.stat4'),
      gradient: "from-green-500 to-cyan-500",
    },
  ];

  return (
    <section className="relative py-32 bg-white overflow-hidden">
      {/* Background Decorations */}
      <motion.div
        className="absolute top-1/3 left-0 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{
          background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
        }}
        animate={{
          scale: [1, 1.5, 1],
          x: [0, 50, 0],
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
      />

      <motion.div
        className="absolute bottom-20 right-0 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{
          background: "linear-gradient(135deg, rgb(6, 182, 212), rgb(79, 70, 229))",
        }}
        animate={{
          scale: [1, 1.4, 1],
          x: [0, -50, 0],
        }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut", delay: 1 }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-block px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full mb-6"
          >
            {t('about.trust.badge')}
          </motion.div>

          <h2 className="text-5xl md:text-6xl font-black mb-6">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('about.trust.title')}
            </span>
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('about.trust.subtitle')}
          </p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.5 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{
                  duration: 0.6,
                  delay: index * 0.1,
                  type: "spring",
                  bounce: 0.5,
                }}
                whileHover={{ y: -10, scale: 1.05 }}
                className="relative group"
              >
                {/* Glow Effect */}
                <motion.div
                  className={`absolute -inset-1 bg-gradient-to-r ${stat.gradient} rounded-3xl opacity-0 group-hover:opacity-40 blur-xl transition-opacity duration-500`}
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: index * 0.5,
                  }}
                />

                {/* Card */}
                <div className="relative bg-gradient-to-br from-white to-gray-50 p-10 rounded-3xl border border-gray-100 shadow-xl text-center">
                  {/* Icon */}
                  <motion.div
                    initial={{ scale: 0, rotate: -180 }}
                    whileInView={{ scale: 1, rotate: 0 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.8,
                      delay: index * 0.1 + 0.3,
                      type: "spring",
                      bounce: 0.6,
                    }}
                    whileHover={{ rotate: 360 }}
                    className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${stat.gradient} flex items-center justify-center shadow-lg`}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Counter with Glow */}
                  <motion.div
                    className={`text-5xl md:text-6xl font-black mb-4 bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{
                      duration: 0.6,
                      delay: index * 0.1 + 0.5,
                      type: "spring",
                    }}
                  >
                    <Counter end={stat.value} suffix={stat.suffix} duration={2.5} />
                  </motion.div>

                  {/* Label */}
                  <p className="text-lg font-semibold text-gray-700">
                    {stat.label}
                  </p>

                  {/* Animated Pulse Dot */}
                  <motion.div
                    className={`absolute top-6 right-6 w-3 h-3 rounded-full bg-gradient-to-r ${stat.gradient}`}
                    animate={{
                      scale: [1, 1.8, 1],
                      opacity: [0.5, 1, 0.5],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: index * 0.3,
                    }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom Testimonial */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-20 text-center"
        >
          <div className="max-w-4xl mx-auto bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-cyan-500/10 p-10 md:p-12 rounded-3xl border border-purple-200 shadow-xl">
            <p className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
              {t('about.trust.quoteText')}
            </p>
            <p className="text-lg text-gray-600 italic">
              {t('about.trust.quoteAuthor')}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
