import { motion } from "motion/react";
import { useLanguage } from "@/contexts/LanguageContext";
import { Search, Lightbulb, Palette, TestTube, Rocket } from "lucide-react";

export function OurProcess() {
  const { t } = useLanguage();

  const steps = [
    {
      icon: Search,
      number: "01",
      title: t('about.process.step1'),
      gradient: "from-blue-500 to-cyan-500",
    },
    {
      icon: Lightbulb,
      number: "02",
      title: t('about.process.step2'),
      gradient: "from-purple-500 to-pink-500",
    },
    {
      icon: Palette,
      number: "03",
      title: t('about.process.step3'),
      gradient: "from-cyan-500 to-blue-500",
    },
    {
      icon: TestTube,
      number: "04",
      title: t('about.process.step4'),
      gradient: "from-green-500 to-cyan-500",
    },
    {
      icon: Rocket,
      number: "05",
      title: t('about.process.step5'),
      gradient: "from-purple-500 to-blue-500",
    },
  ];

  return (
    <section className="relative py-32 bg-gradient-to-br from-gray-50 to-blue-50/30 overflow-hidden">
      {/* Background Decoration */}
      <motion.div
        className="absolute top-20 left-10 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{
          background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
        }}
        animate={{
          scale: [1, 1.4, 1],
          rotate: [0, 180, 0],
        }}
        transition={{ duration: 25, repeat: Infinity, ease: "easeInOut" }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="inline-block px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full mb-6"
          >
            {t('about.process.badge')}
          </motion.div>

          <h2 className="text-5xl md:text-6xl font-black mb-6">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('about.process.title')}
            </span>
          </h2>

          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {t('about.process.subtitle')}
          </p>
        </motion.div>

        {/* Process Flow */}
        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute top-24 left-0 right-0 h-1">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-500 via-purple-500 to-cyan-500 rounded-full"
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 2, ease: "easeInOut" }}
              style={{ transformOrigin: "left" }}
            />
          </div>

          {/* Steps Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-100px" }}
                  transition={{
                    duration: 0.6,
                    delay: index * 0.15,
                    type: "spring",
                    bounce: 0.4,
                  }}
                  className="relative"
                >
                  {/* Step Card */}
                  <motion.div
                    whileHover={{ y: -15, scale: 1.05 }}
                    className="relative group"
                  >
                    {/* Glow on Hover */}
                    <div
                      className={`absolute -inset-1 bg-gradient-to-r ${step.gradient} rounded-3xl opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-500`}
                    />

                    {/* Card Content */}
                    <div className="relative bg-white p-6 rounded-3xl border border-gray-100 shadow-lg text-center">
                      {/* Icon Circle */}
                      <motion.div
                        initial={{ scale: 0, rotate: -180 }}
                        whileInView={{ scale: 1, rotate: 0 }}
                        viewport={{ once: true }}
                        transition={{
                          duration: 0.6,
                          delay: index * 0.15 + 0.3,
                          type: "spring",
                          bounce: 0.5,
                        }}
                        whileHover={{ rotate: 360 }}
                        className={`w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-r ${step.gradient} flex items-center justify-center shadow-xl relative z-10`}
                      >
                        <Icon className="w-10 h-10 text-white" />
                      </motion.div>

                      {/* Step Number */}
                      <motion.div
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: index * 0.15 + 0.5 }}
                        className={`text-6xl font-black mb-2 bg-gradient-to-r ${step.gradient} bg-clip-text text-transparent opacity-20`}
                      >
                        {step.number}
                      </motion.div>

                      {/* Title */}
                      <h3 className="text-lg font-bold text-gray-900 leading-tight">
                        {step.title}
                      </h3>

                      {/* Animated Dot */}
                      <motion.div
                        className={`absolute -bottom-2 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-gradient-to-r ${step.gradient}`}
                        animate={{
                          scale: [1, 1.5, 1],
                          opacity: [0.5, 1, 0.5],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeInOut",
                          delay: index * 0.3,
                        }}
                      />
                    </div>
                  </motion.div>

                  {/* Arrow for Mobile */}
                  {index < steps.length - 1 && (
                    <motion.div
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.15 + 0.6 }}
                      className="lg:hidden flex justify-center my-4"
                    >
                      <div className="w-0.5 h-12 bg-gradient-to-b from-blue-500 to-purple-500 rounded-full" />
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom Message */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="mt-20 text-center"
        >
          <div className="inline-block px-10 py-6 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-cyan-500/10 rounded-3xl border border-purple-200 shadow-lg">
            <p className="text-xl md:text-2xl font-bold text-gray-800">
              {t('about.process.bottomText')}
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
