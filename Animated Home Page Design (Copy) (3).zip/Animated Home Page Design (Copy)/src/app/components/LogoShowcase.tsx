import { Logo, LogoIcon, LogoMonochrome, LogoSquare, LogoDark } from "./Logo";
import { LogoSVGFull, LogoSVGIcon, LogoSVGSquareGradient, LogoSVGMonochromeDark, LogoSVGMonochromeLight, downloadSVG } from "./LogoExport";

export function LogoShowcase() {
  const handleDownloadAll = () => {
    downloadSVG(LogoSVGFull, 'helloclient-logo-full-color.svg');
    setTimeout(() => downloadSVG(LogoSVGIcon, 'helloclient-logo-icon.svg'), 100);
    setTimeout(() => downloadSVG(LogoSVGSquareGradient, 'helloclient-app-icon-gradient.svg'), 200);
    setTimeout(() => downloadSVG(LogoSVGMonochromeDark, 'helloclient-logo-monochrome-dark.svg'), 300);
    setTimeout(() => downloadSVG(LogoSVGMonochromeLight, 'helloclient-logo-monochrome-light.svg'), 400);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-4">
            Hello Client.in Brand Assets
          </h1>
          <p className="text-xl text-gray-600">
            Tech-Startup Grade Logo System • Clean • Scalable • Professional
          </p>
        </div>

        {/* Main Logo - Light Background */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Primary Logo - Light Background</h2>
          <div className="bg-white rounded-2xl shadow-lg p-16 flex items-center justify-center border border-gray-200">
            <Logo variant="default" />
          </div>
          <p className="text-sm text-gray-500 mt-3">Use this on white or light backgrounds</p>
        </section>

        {/* Main Logo - Dark Background */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Primary Logo - Dark Background</h2>
          <div className="bg-gray-900 rounded-2xl shadow-lg p-16 flex items-center justify-center">
            <LogoDark />
          </div>
          <p className="text-sm text-gray-500 mt-3">Use this on dark backgrounds with cyan glow effect</p>
        </section>

        {/* Icon Only Variants */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Icon Only - Various Sizes</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Favicon */}
            <div className="bg-white rounded-2xl shadow-lg p-12 flex flex-col items-center justify-center border border-gray-200">
              <LogoIcon size={24} />
              <p className="text-sm text-gray-600 mt-4 font-semibold">24px - Favicon</p>
            </div>
            
            {/* Small */}
            <div className="bg-white rounded-2xl shadow-lg p-12 flex flex-col items-center justify-center border border-gray-200">
              <LogoIcon size={40} />
              <p className="text-sm text-gray-600 mt-4 font-semibold">40px - Header</p>
            </div>
            
            {/* Medium */}
            <div className="bg-white rounded-2xl shadow-lg p-12 flex flex-col items-center justify-center border border-gray-200">
              <LogoIcon size={64} />
              <p className="text-sm text-gray-600 mt-4 font-semibold">64px - App Icon</p>
            </div>
            
            {/* Large */}
            <div className="bg-white rounded-2xl shadow-lg p-12 flex flex-col items-center justify-center border border-gray-200">
              <LogoIcon size={128} />
              <p className="text-sm text-gray-600 mt-4 font-semibold">128px - Social Media</p>
            </div>
          </div>
        </section>

        {/* Square Variants for App Icons */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Square Icon Variants - App & Social</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Gradient Background */}
            <div className="flex flex-col items-center">
              <LogoSquare size={256} background="gradient" />
              <p className="text-sm text-gray-600 mt-4 font-semibold">Gradient Background</p>
              <p className="text-xs text-gray-500">iOS App Icon, Social Media</p>
            </div>
            
            {/* Solid Background */}
            <div className="flex flex-col items-center">
              <LogoSquare size={256} background="solid" />
              <p className="text-sm text-gray-600 mt-4 font-semibold">Solid Deep Indigo</p>
              <p className="text-xs text-gray-500">Android App Icon</p>
            </div>
            
            {/* Transparent */}
            <div className="flex flex-col items-center">
              <div className="bg-white border-2 border-gray-200 rounded-2xl p-8">
                <LogoSquare size={256} background="transparent" />
              </div>
              <p className="text-sm text-gray-600 mt-4 font-semibold">Transparent</p>
              <p className="text-xs text-gray-500">Flexible Use</p>
            </div>
          </div>
        </section>

        {/* Monochrome Variants */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Monochrome Versions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Dark Version */}
            <div className="bg-white rounded-2xl shadow-lg p-16 flex flex-col items-center justify-center border border-gray-200">
              <LogoMonochrome variant="dark" />
              <p className="text-sm text-gray-600 mt-4">Dark - For light backgrounds</p>
            </div>
            
            {/* Light Version */}
            <div className="bg-gray-900 rounded-2xl shadow-lg p-16 flex flex-col items-center justify-center">
              <LogoMonochrome variant="light" />
              <p className="text-sm text-gray-400 mt-4">Light - For dark backgrounds</p>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-3">Use monochrome versions for print, embroidery, or single-color applications</p>
        </section>

        {/* Spacing Guidelines */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Minimum Clear Space</h2>
          <div className="bg-white rounded-2xl shadow-lg p-16 flex items-center justify-center border border-gray-200 relative">
            <div className="relative">
              <Logo variant="default" />
              {/* Clear space indicators */}
              <div className="absolute -inset-10 border-2 border-dashed border-indigo-400 pointer-events-none"></div>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-3">Maintain minimum clear space equal to the icon height on all sides</p>
        </section>

        {/* Color Palette */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Brand Colors - Tech Startup Identity</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
              <div className="h-32 bg-[#3730A3]"></div>
              <div className="p-4">
                <p className="font-semibold text-gray-900">Deep Indigo</p>
                <p className="text-sm text-gray-600">#3730A3</p>
                <p className="text-xs text-gray-500 mt-1">Primary Icon</p>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
              <div className="h-32 bg-[#4F46E5]"></div>
              <div className="p-4">
                <p className="font-semibold text-gray-900">Electric Indigo</p>
                <p className="text-sm text-gray-600">#4F46E5</p>
                <p className="text-xs text-gray-500 mt-1">Accent</p>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
              <div className="h-32 bg-[#06B6D4]"></div>
              <div className="p-4">
                <p className="font-semibold text-gray-900">Cyan</p>
                <p className="text-sm text-gray-600">#06B6D4</p>
                <p className="text-xs text-gray-500 mt-1">Highlight</p>
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
              <div className="h-32 bg-[#111827]"></div>
              <div className="p-4">
                <p className="font-semibold text-gray-900">Near Black</p>
                <p className="text-sm text-gray-600">#111827</p>
                <p className="text-xs text-gray-500 mt-1">Typography</p>
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-4">Clean, confident color system designed for a modern SaaS brand identity</p>
        </section>

        {/* Usage Examples */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Real-World Applications</h2>
          
          <div className="space-y-8">
            {/* Website Header */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Website Header</h3>
              <div className="bg-white rounded-xl shadow-lg p-6 flex items-center justify-between border border-gray-200">
                <Logo variant="default" />
                <div className="flex gap-6 text-sm font-medium text-gray-600">
                  <span>Home</span>
                  <span>About</span>
                  <span>Services</span>
                  <span>Contact</span>
                </div>
              </div>
            </div>

            {/* Business Card */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Business Card</h3>
              <div className="bg-gradient-to-br from-[#3730A3] via-[#4F46E5] to-[#06B6D4] rounded-xl shadow-lg p-8 max-w-md">
                <LogoDark />
                <div className="mt-8 text-white">
                  <p className="font-bold text-lg">Rajesh Kumar</p>
                  <p className="text-sm opacity-90">Digital Strategy Lead</p>
                  <p className="text-sm opacity-80 mt-4">hello@helloclient.in</p>
                  <p className="text-sm opacity-80">+91 93106 78042</p>
                </div>
              </div>
            </div>

            {/* App Icon Preview */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3">Mobile App Icons</h3>
              <div className="flex items-center gap-8">
                <LogoSquare size={96} background="gradient" />
                <LogoSquare size={96} background="solid" />
                <div className="bg-gray-100 rounded-2xl p-4">
                  <LogoSquare size={96} background="transparent" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Don'ts */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Logo Usage Guidelines</h2>
          <div className="bg-red-50 rounded-xl p-8 border-2 border-red-200">
            <h3 className="font-bold text-red-900 mb-4 flex items-center gap-2">
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              Don't
            </h3>
            <ul className="space-y-2 text-red-800">
              <li>• Don't change the logo colors</li>
              <li>• Don't rotate or distort the logo</li>
              <li>• Don't add effects like shadows or outlines</li>
              <li>• Don't place logo on busy backgrounds</li>
              <li>• Don't recreate or modify the logo</li>
              <li>• Don't use low-resolution versions</li>
            </ul>
          </div>
        </section>

        {/* Download Instructions */}
        <section>
          <div className="bg-gradient-to-r from-[#4F46E5] to-[#06B6D4] rounded-2xl shadow-xl p-12 text-center text-white">
            <h2 className="text-3xl font-bold mb-4">Need Logo Files?</h2>
            <p className="text-lg opacity-90 mb-6">
              Download high-resolution SVG, PNG, and vector files for all your branding needs
            </p>
            <div className="flex flex-wrap gap-4 justify-center">
              <button className="bg-white text-gray-900 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors" onClick={handleDownloadAll}>
                Download Full Package
              </button>
              <button className="bg-white/20 backdrop-blur-sm text-white px-8 py-3 rounded-full font-semibold hover:bg-white/30 transition-colors">
                View Brand Guidelines
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}