import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { Search, Globe, Smartphone, Palette, TrendingUp, Mail } from "lucide-react";

const services = [
  {
    icon: Search,
    label: "SEO",
    color: "from-blue-500 to-cyan-500",
    rgbGradient: "linear-gradient(to bottom right, rgb(59, 130, 246), rgb(6, 182, 212))",
    position: { desktop: { x: -200, y: -150 }, mobile: { x: -80, y: -100 } },
  },
  {
    icon: Globe,
    label: "Website",
    color: "from-purple-500 to-pink-500",
    rgbGradient: "linear-gradient(to bottom right, rgb(168, 85, 247), rgb(236, 72, 153))",
    position: { desktop: { x: 200, y: -120 }, mobile: { x: 80, y: -80 } },
  },
  {
    icon: Smartphone,
    label: "App",
    color: "from-green-500 to-teal-500",
    rgbGradient: "linear-gradient(to bottom right, rgb(34, 197, 94), rgb(20, 184, 166))",
    position: { desktop: { x: -220, y: 100 }, mobile: { x: -90, y: 80 } },
  },
  {
    icon: Palette,
    label: "Design",
    color: "from-orange-500 to-red-500",
    rgbGradient: "linear-gradient(to bottom right, rgb(249, 115, 22), rgb(239, 68, 68))",
    position: { desktop: { x: 220, y: 130 }, mobile: { x: 90, y: 100 } },
  },
  {
    icon: TrendingUp,
    label: "Marketing",
    color: "from-indigo-500 to-purple-500",
    rgbGradient: "linear-gradient(to bottom right, rgb(99, 102, 241), rgb(168, 85, 247))",
    position: { desktop: { x: 0, y: -180 }, mobile: { x: 0, y: -120 } },
  },
  {
    icon: Mail,
    label: "Email",
    color: "from-pink-500 to-rose-500",
    rgbGradient: "linear-gradient(to bottom right, rgb(236, 72, 153), rgb(244, 63, 94))",
    position: { desktop: { x: 0, y: 180 }, mobile: { x: 0, y: 120 } },
  },
];

export function FloatingCharacter() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-50, 50]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 360]);

  return (
    <section
      ref={containerRef}
      className="relative py-32 overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50"
      style={{ position: 'relative' }}
    >
      {/* Floating Shapes */}
      <motion.div
        className="absolute top-20 left-10 w-32 h-32 rounded-full blur-3xl"
        style={{
          background: 'linear-gradient(to bottom right, rgb(191, 219, 254), rgb(221, 214, 254))',
          opacity: 0.3,
        }}
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 30, 0],
          y: [0, 20, 0],
        }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-20 right-10 w-40 h-40 rounded-full blur-3xl"
        style={{
          background: 'linear-gradient(to bottom right, rgb(165, 243, 252), rgb(191, 219, 254))',
          opacity: 0.3,
        }}
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -30, 0],
          y: [0, -20, 0],
        }}
        transition={{ duration: 8, repeat: Infinity, delay: 1 }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full"
          >
            All-in-One Solution
          </motion.div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black text-gray-900 mb-6">
            Complete Digital
            <br />
            <span className="bg-gradient-to-r from-[#4F46E5] via-[#9333EA] to-[#06B6D4] bg-clip-text text-transparent">
              Ecosystem
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Everything your business needs to thrive online
          </p>
        </motion.div>

        {/* Central Illustration */}
        <div className="relative h-[600px] md:h-[700px] flex items-center justify-center">
          <motion.div style={{ y: y1 }}>
            {/* Character Circle */}
            <motion.div
              className="relative w-64 h-64 md:w-80 md:h-80"
              animate={{
                y: [0, -20, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              {/* Main Circle */}
              <motion.div
                className="w-full h-full rounded-full bg-gradient-to-br from-blue-500 via-purple-500 to-cyan-500 shadow-2xl flex items-center justify-center relative overflow-hidden"
                animate={{
                  rotate: 360,
                }}
                transition={{
                  duration: 30,
                  repeat: Infinity,
                  ease: "linear",
                }}
              >
                {/* Inner Circle */}
                <motion.div
                  className="absolute inset-4 rounded-full bg-white shadow-inner flex items-center justify-center"
                  animate={{
                    rotate: -360,
                  }}
                  transition={{
                    duration: 30,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                >
                  {/* Phone Icon */}
                  <motion.div
                    className="relative"
                    animate={{
                      rotate: 0,
                    }}
                  >
                    <div className="w-24 h-40 md:w-32 md:h-48 bg-gradient-to-br from-gray-800 to-gray-900 rounded-3xl shadow-2xl border-4 border-gray-700 relative">
                      {/* Screen */}
                      <div className="absolute inset-3 bg-gradient-to-br from-blue-400 via-purple-400 to-cyan-400 rounded-2xl" />
                      {/* Notch */}
                      <div className="absolute top-3 left-1/2 -translate-x-1/2 w-12 h-1 bg-gray-700 rounded-full" />
                    </div>
                  </motion.div>
                </motion.div>
              </motion.div>

              {/* Glow Effect */}
              <motion.div
                className="absolute inset-0 rounded-full blur-3xl"
                style={{
                  background: 'linear-gradient(to bottom right, rgb(59, 130, 246), rgb(147, 51, 234))',
                }}
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                }}
              />
            </motion.div>

            {/* Floating Service Icons */}
            {services.map((service, index) => {
              const Icon = service.icon;
              const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
              const pos = isMobile ? service.position.mobile : service.position.desktop;

              return (
                <motion.div
                  key={index}
                  className="absolute"
                  style={{
                    left: "50%",
                    top: "50%",
                    x: pos.x,
                    y: pos.y,
                  }}
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.6,
                    delay: index * 0.1,
                    type: "spring",
                    stiffness: 100,
                  }}
                >
                  <motion.div
                    animate={{
                      y: [0, -15, 0],
                    }}
                    transition={{
                      duration: 3 + index * 0.5,
                      repeat: Infinity,
                      ease: "easeInOut",
                      delay: index * 0.2,
                    }}
                  >
                    <motion.div
                      className={`relative w-16 h-16 md:w-20 md:h-20 bg-gradient-to-br ${service.color} rounded-2xl shadow-2xl flex items-center justify-center cursor-pointer`}
                      whileHover={{ scale: 1.2, rotate: 360 }}
                      transition={{ duration: 0.4 }}
                    >
                      <Icon className="w-8 h-8 md:w-10 md:h-10 text-white" />

                      {/* Glow */}
                      <motion.div
                        className="absolute inset-0 rounded-2xl blur-xl"
                        style={{
                          background: service.rgbGradient,
                        }}
                        animate={{
                          scale: [1, 1.3, 1],
                          opacity: [0.3, 0.6, 0.3],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          delay: index * 0.3,
                        }}
                      />

                      {/* Label */}
                      <motion.div
                        className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap opacity-0 hover:opacity-100 transition-opacity"
                        initial={{ opacity: 0 }}
                      >
                        <span className="text-sm font-bold text-gray-700 bg-white px-3 py-1 rounded-full shadow-lg">
                          {service.label}
                        </span>
                      </motion.div>
                    </motion.div>
                  </motion.div>
                </motion.div>
              );
            })}

            {/* Connecting Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-20">
              {services.map((service, index) => {
                const isMobile = typeof window !== "undefined" && window.innerWidth < 768;
                const pos = isMobile ? service.position.mobile : service.position.desktop;
                return (
                  <motion.line
                    key={index}
                    x1="50%"
                    y1="50%"
                    x2={`calc(50% + ${pos.x}px)`}
                    y2={`calc(50% + ${pos.y}px)`}
                    stroke="url(#serviceGradient)"
                    strokeWidth="2"
                    strokeDasharray="4,4"
                    initial={{ pathLength: 0 }}
                    whileInView={{ pathLength: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 1, delay: index * 0.1 }}
                  />
                );
              })}
              <defs>
                <linearGradient id="serviceGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#4F46E5" />
                  <stop offset="50%" stopColor="#9333EA" />
                  <stop offset="100%" stopColor="#06B6D4" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
        </div>
      </div>
    </section>
  );
}