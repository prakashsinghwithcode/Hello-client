import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { useLocation, Link } from "react-router-dom";
import { Menu, X } from "lucide-react";
import { Logo } from "./Logo";
import { LanguageSelector } from "./LanguageSelector";
import { useLanguage } from "@/contexts/LanguageContext";

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { t } = useLanguage();

  const navLinks = [
    { label: t('nav.home'), href: "/" },
    { label: t('nav.about'), href: "/about" },
    { label: t('nav.services'), href: "/services" },
    { label: t('nav.contact'), href: "/contact" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu when route changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled || mobileMenuOpen
          ? "bg-white shadow-lg"
          : "bg-white/90 backdrop-blur-sm md:bg-transparent"
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="z-50"
          >
            <Logo />
          </motion.div>

          {/* Desktop Navigation Links */}
          <motion.div
            className="hidden md:flex items-center gap-2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            {navLinks.map((link, index) => {
              const isActive = location.pathname === link.href;

              return (
                <motion.div key={index}>
                  <Link
                    to={link.href}
                    className={`relative px-6 py-2.5 rounded-full font-semibold transition-all ${
                      isActive
                        ? "text-white bg-gradient-to-r from-[#4F46E5] to-[#9333EA]"
                        : scrolled
                        ? "text-gray-700 hover:text-[#4F46E5] hover:bg-gray-100"
                        : "text-gray-800 hover:text-[#4F46E5] hover:bg-white/80"
                    }`}
                  >
                    {link.label}
                    
                    {/* Active Glow Effect */}
                    {isActive && (
                      <motion.div
                        className="absolute inset-0 rounded-full blur-md -z-10"
                        style={{
                          background: 'linear-gradient(to right, rgb(79, 70, 229), rgb(147, 51, 234))',
                        }}
                        animate={{
                          scale: [1, 1.2, 1],
                          opacity: [0.3, 0.5, 0.3],
                        }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                        }}
                      />
                    )}
                  </Link>
                </motion.div>
              );
            })}
            
            {/* Language Selector */}
            <LanguageSelector />
          </motion.div>

          {/* Mobile Menu Button & Language Selector */}
          <div className="flex items-center gap-3 md:hidden z-50">
            <LanguageSelector />
            <motion.button
              className={`p-2 rounded-lg ${
                scrolled || mobileMenuOpen ? "text-gray-900" : "text-gray-900"
              }`}
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              whileTap={{ scale: 0.95 }}
            >
              {mobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </motion.button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            className="md:hidden fixed top-16 left-0 right-0 bottom-0 bg-white z-40 overflow-y-auto"
            initial={{ opacity: 0, x: "100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "100%" }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
          >
            <div className="px-4 py-8 space-y-2">
              {navLinks.map((link, index) => {
                const isActive = location.pathname === link.href;

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link
                      to={link.href}
                      className={`block w-full px-6 py-4 rounded-2xl font-semibold text-lg transition-all ${
                        isActive
                          ? "text-white bg-gradient-to-r from-[#4F46E5] to-[#9333EA] shadow-lg"
                          : "text-gray-700 hover:bg-gray-100"
                      }`}
                    >
                      {link.label}
                    </Link>
                  </motion.div>
                );
              })}

              {/* Mobile CTA Button */}
              <motion.div
                className="pt-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: navLinks.length * 0.1 }}
              >
                <Link
                  to="/contact"
                  className="block w-full px-6 py-5 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] text-white text-center font-bold rounded-2xl shadow-xl"
                >
                  {t('nav.contact')}
                </Link>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}