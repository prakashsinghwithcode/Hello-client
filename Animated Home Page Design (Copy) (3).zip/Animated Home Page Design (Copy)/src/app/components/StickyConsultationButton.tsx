import { motion, AnimatePresence } from "motion/react";
import { Phone, X, Mail, MessageCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useConsultation } from "@/contexts/ConsultationContext";

export function StickyConsultationButton() {
  const { showConsultation, openConsultation, closeConsultation } = useConsultation();
  const { t } = useLanguage();

  return (
    <>
      {/* Floating Button */}
      <motion.button
        className="fixed bottom-6 right-6 md:bottom-8 md:right-8 z-50 w-14 h-14 md:w-16 md:h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 shadow-2xl flex items-center justify-center text-white"
        onClick={openConsultation}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        animate={{
          y: [0, -10, 0],
        }}
        transition={{
          y: {
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          },
        }}
      >
        <Phone className="w-6 h-6 md:w-7 md:h-7" />

        {/* Ripple Effect */}
        <motion.div
          className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500 to-purple-500"
          animate={{
            scale: [1, 1.8],
            opacity: [0.6, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
          }}
        />

        {/* Pulse Ring */}
        <motion.div
          className="absolute inset-0 rounded-full border-4 border-blue-500"
          animate={{
            scale: [1, 1.5],
            opacity: [1, 0],
          }}
          transition={{
            duration: 1.5,
            repeat: Infinity,
          }}
        />
      </motion.button>

      {/* Modal */}
      <AnimatePresence>
        {showConsultation && (
          <>
            {/* Backdrop */}
            <motion.div
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeConsultation}
            />

            {/* Modal Content */}
            <motion.div
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-lg mx-4"
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
            >
              <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
                {/* Header */}
                <div className="relative p-8 bg-gradient-to-br from-blue-500 to-purple-500 text-white">
                  <button
                    onClick={closeConsultation}
                    className="absolute top-4 right-4 w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>

                  <motion.div
                    animate={{
                      rotate: [0, 10, -10, 0],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                    }}
                  >
                    <Phone className="w-12 h-12 mb-4" />
                  </motion.div>

                  <h3 className="text-3xl font-black mb-2">{t('nav.getConsultation')}</h3>
                  <p className="text-white/90">
                    {t('cta.subtitle')}
                  </p>
                </div>

                {/* Content */}
                <div className="p-8 space-y-4">
                  {/* Phone */}
                  <motion.a
                    href="tel:+919876543210"
                    className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-transparent hover:border-blue-500 transition-all group"
                    whileHover={{ scale: 1.02, x: 5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center flex-shrink-0">
                      <Phone className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-600 mb-1">Call Now</div>
                      <div className="text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">
                        +91 93106 78042
                      </div>
                    </div>
                    <motion.div
                      className="text-blue-500"
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      →
                    </motion.div>
                  </motion.a>

                  {/* WhatsApp */}
                  <motion.a
                    href="https://wa.me/919310678042"
                    className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-br from-green-50 to-teal-50 border-2 border-transparent hover:border-green-500 transition-all group"
                    whileHover={{ scale: 1.02, x: 5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-green-500 to-teal-500 flex items-center justify-center flex-shrink-0">
                      <MessageCircle className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-600 mb-1">WhatsApp</div>
                      <div className="text-xl font-bold text-gray-900 group-hover:text-green-600 transition-colors">
                        Chat with us
                      </div>
                    </div>
                    <motion.div
                      className="text-green-500"
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      →
                    </motion.div>
                  </motion.a>

                  {/* Email */}
                  <motion.a
                    href="mailto:info@helloclient.in"
                    className="flex items-center gap-4 p-4 rounded-2xl bg-gradient-to-br from-orange-50 to-red-50 border-2 border-transparent hover:border-orange-500 transition-all group"
                    whileHover={{ scale: 1.02, x: 5 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-orange-500 to-red-500 flex items-center justify-center flex-shrink-0">
                      <Mail className="w-7 h-7 text-white" />
                    </div>
                    <div className="flex-1">
                      <div className="text-sm text-gray-600 mb-1">Email</div>
                      <div className="text-lg font-bold text-gray-900 group-hover:text-orange-600 transition-colors">
                        info@helloclient.in
                      </div>
                    </div>
                    <motion.div
                      className="text-orange-500"
                      animate={{ x: [0, 5, 0] }}
                      transition={{ duration: 1, repeat: Infinity }}
                    >
                      →
                    </motion.div>
                  </motion.a>

                  {/* Business Hours */}
                  <div className="mt-6 p-4 rounded-2xl bg-gray-50">
                    <div className="font-bold text-gray-900 mb-2">
                      Business Hours
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <div>Mon - Sat: 9:00 AM - 8:00 PM</div>
                      <div>Sunday: 10:00 AM - 6:00 PM</div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}