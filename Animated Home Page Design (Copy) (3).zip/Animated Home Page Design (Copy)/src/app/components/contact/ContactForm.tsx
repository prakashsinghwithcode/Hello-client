import { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import { Send, CheckCircle, Sparkles } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuote } from "@/contexts/QuoteContext";
import { Input } from "@/app/components/ui/input";
import { Textarea } from "@/app/components/ui/textarea";
import { Label } from "@/app/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import emailjs from "@emailjs/browser";

export function ContactForm() {
  const { t } = useLanguage();
  const { isQuoteMode, selectedService } = useQuote();
  const formRef = useRef<HTMLDivElement>(null);

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    company: "",
    service: "",
    brief: "",
  });

  useEffect(() => {
    if (isQuoteMode && formRef.current) {
      const timer = setTimeout(() => {
        formRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [isQuoteMode]);

  useEffect(() => {
    if (isQuoteMode && selectedService) {
      setFormData((prev) => ({ ...prev, service: selectedService }));
    }
  }, [isQuoteMode, selectedService]);

  // 🔥 EMAILJS SUBMIT (ONLY LOGIC CHANGE)
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
  e.preventDefault();

  emailjs.send(
    import.meta.env.VITE_EMAILJS_SERVICE_ID,
    import.meta.env.VITE_EMAILJS_TEMPLATE_ID,
    {
      name: formData.fullName,        // {{name}}
      email: formData.email,          // {{email}}
      title: formData.service,        // {{title}}
      message: `
Phone: ${formData.phone}
Company: ${formData.company}

${formData.brief}
      `,                              // {{message}}
    },
    import.meta.env.VITE_EMAILJS_PUBLIC_KEY
  ).then(
    () => {
      setIsSubmitted(true);
      setTimeout(() => {
        setIsSubmitted(false);
        setFormData({
          fullName: "",
          email: "",
          phone: "",
          company: "",
          service: "",
          brief: "",
        });
      }, 3000);
    },
    (error) => {
      console.error("EmailJS Error:", error);
      alert("Failed to send message");
    }
  );
};


  return (
    <motion.div
      ref={formRef}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
      className="relative"
    >
      {isQuoteMode && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.3, type: "spring" }}
          className="mb-6 p-5 rounded-2xl bg-gradient-to-r from-purple-50 via-blue-50 to-cyan-50 border border-purple-200/50 flex items-start gap-3"
        >
          <Sparkles className="w-6 h-6 mt-0.5 text-purple-600" />
          <div>
            <h3 className="font-bold text-lg text-indigo-600">
              Personalized Quote Awaits
            </h3>
            <p className="text-sm text-gray-700">
              Tell us your requirements and we'll prepare a personalized quote.
            </p>
          </div>
        </motion.div>
      )}

      <motion.div className="bg-white rounded-3xl p-8 md:p-10 shadow-xl border">
        <h2 className="text-3xl md:text-4xl font-bold mb-2">
          <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-600 to-purple-600">
            {t("contact.info.title")}
          </span>
        </h2>

        {isSubmitted ? (
          <div className="flex flex-col items-center py-12">
            <CheckCircle className="w-20 h-20 text-green-500 mb-4" />
            <h3 className="text-2xl font-bold text-indigo-600">
              {t("contact.form.success")}
            </h3>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div>
              <Label>{t("contact.form.fullName")}</Label>
              <Input
                value={formData.fullName}
                onChange={(e) =>
                  setFormData({ ...formData, fullName: e.target.value })
                }
                required
              />
            </div>

            {/* Email & Phone */}
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label>{t("contact.form.email")}</Label>
                <Input
                  type="email"
                  value={formData.email}
                  onChange={(e) =>
                    setFormData({ ...formData, email: e.target.value })
                  }
                  required
                />
              </div>

              <div>
                <Label>{t("contact.form.phone")}</Label>
                <Input
                  value={formData.phone}
                  onChange={(e) =>
                    setFormData({ ...formData, phone: e.target.value })
                  }
                  required
                />
              </div>
            </div>

            {/* Company */}
            <div>
              <Label>{t("contact.form.companyOptional")}</Label>
              <Input
                value={formData.company}
                onChange={(e) =>
                  setFormData({ ...formData, company: e.target.value })
                }
              />
            </div>

            {/* Service */}
            <div>
              <Label>{t("contact.form.service")}</Label>
              <Select
                value={formData.service}
                onValueChange={(value) =>
                  setFormData({ ...formData, service: value })
                }
              >
                <SelectTrigger>
                  <SelectValue
                    placeholder={t("contact.form.servicePlaceholder")}
                  />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="web">Web</SelectItem>
                  <SelectItem value="app">App</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="design">Design</SelectItem>
                  <SelectItem value="branding">Branding</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Brief */}
            <div>
              <Label>{t("contact.form.brief")}</Label>
              <Textarea
                rows={5}
                value={formData.brief}
                onChange={(e) =>
                  setFormData({ ...formData, brief: e.target.value })
                }
                required
              />
            </div>

            {/* Submit */}
            <motion.button
              type="submit"
              className="w-full h-14 rounded-xl font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 flex items-center justify-center gap-2"
            >
              {t("contact.form.submit")}
              <Send className="w-5 h-5" />
            </motion.button>
          </form>
        )}
      </motion.div>
    </motion.div>
  );
}