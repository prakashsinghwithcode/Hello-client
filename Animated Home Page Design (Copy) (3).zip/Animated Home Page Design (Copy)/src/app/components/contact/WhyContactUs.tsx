import { motion } from "motion/react";
import { Gift, Zap, Users, MessageSquare } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const whyPoints = [
  {
    icon: Gift,
    titleKey: 'contact.why.point1',
    descKey: 'contact.why.point1Desc',
    gradient: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
  },
  {
    icon: Zap,
    titleKey: 'contact.why.point2',
    descKey: 'contact.why.point2Desc',
    gradient: "linear-gradient(135deg, rgb(147, 51, 234), rgb(6, 182, 212))",
  },
  {
    icon: Users,
    titleKey: 'contact.why.point3',
    descKey: 'contact.why.point3Desc',
    gradient: "linear-gradient(135deg, rgb(6, 182, 212), rgb(79, 70, 229))",
  },
  {
    icon: MessageSquare,
    titleKey: 'contact.why.point4',
    descKey: 'contact.why.point4Desc',
    gradient: "linear-gradient(135deg, rgb(79, 70, 229), rgb(6, 182, 212))",
  },
];

export function WhyContactUs() {
  const { t } = useLanguage();

  return (
    <section className="relative py-20 bg-gradient-to-b from-white via-blue-50/30 to-white overflow-hidden">
      {/* Background Decoration */}
      <motion.div
        className="absolute top-20 left-10 w-72 h-72 rounded-full blur-3xl opacity-10"
        style={{ background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))" }}
        animate={{
          scale: [1, 1.3, 1],
          x: [0, 50, 0],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('contact.why.title')}
            </span>
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {whyPoints.map((point, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="relative group"
            >
              <div className="bg-white rounded-3xl p-8 shadow-xl shadow-blue-100/50 border border-blue-100/50 h-full relative overflow-hidden">
                {/* Hover Glow Effect */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300"
                  style={{
                    background: point.gradient,
                  }}
                />

                {/* Icon */}
                <motion.div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center mb-6 relative z-10"
                  style={{
                    background: point.gradient,
                  }}
                  whileHover={{ rotate: 360, scale: 1.1 }}
                  transition={{ duration: 0.6 }}
                >
                  <point.icon className="w-8 h-8 text-white" />
                </motion.div>

                {/* Content */}
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    {t(point.titleKey)}
                  </h3>
                  <p className="text-gray-600 leading-relaxed">
                    {t(point.descKey)}
                  </p>
                </div>

                {/* Animated Corner Accent */}
                <motion.div
                  className="absolute -top-10 -right-10 w-32 h-32 rounded-full opacity-20"
                  style={{
                    background: point.gradient,
                  }}
                  animate={{
                    scale: [1, 1.2, 1],
                    rotate: [0, 180, 360],
                  }}
                  transition={{
                    duration: 8,
                    repeat: Infinity,
                    ease: "linear",
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
