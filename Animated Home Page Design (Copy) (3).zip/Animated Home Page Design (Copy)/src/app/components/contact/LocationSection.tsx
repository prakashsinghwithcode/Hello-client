import { motion } from "motion/react";
import { MapPin } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export function LocationSection() {
  const { t } = useLanguage();

  return (
    <section className="relative py-20 bg-gradient-to-b from-white via-purple-50/30 to-white overflow-hidden">
      {/* Background Decoration */}
      <motion.div
        className="absolute top-10 right-10 w-64 h-64 rounded-full blur-3xl opacity-10"
        style={{ background: "linear-gradient(135deg, rgb(147, 51, 234), rgb(6, 182, 212))" }}
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 90, 0],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {t('contact.location.title')}
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            {t('contact.location.text')}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative rounded-3xl overflow-hidden shadow-2xl shadow-purple-200/50 border border-purple-100/50"
        >
          {/* Map Placeholder with Gradient */}
          <div
            className="relative h-96 flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, rgba(79, 70, 229, 0.05), rgba(147, 51, 234, 0.05), rgba(6, 182, 212, 0.05))",
            }}
          >
            {/* Animated Map Marker */}
            <motion.div
              className="relative"
              initial={{ y: -100, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.5, type: "spring", bounce: 0.4 }}
            >
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
              >
                <div
                  className="w-24 h-24 rounded-full flex items-center justify-center shadow-2xl"
                  style={{
                    background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                  }}
                >
                  <MapPin className="w-12 h-12 text-white" />
                </div>
              </motion.div>

              {/* Pulse Effect */}
              <motion.div
                className="absolute inset-0 rounded-full"
                style={{
                  background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                  opacity: 0.3,
                }}
                animate={{
                  scale: [1, 2, 1],
                  opacity: [0.3, 0, 0.3],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
            </motion.div>

            {/* Grid Lines */}
            <svg className="absolute inset-0 w-full h-full opacity-10" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgb(79, 70, 229)" strokeWidth="1"/>
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            {/* Location Details Overlay */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.7 }}
              className="absolute bottom-8 left-8 bg-white/95 backdrop-blur-sm rounded-2xl p-6 shadow-xl border border-white/50"
            >
              <div className="flex items-start gap-4">
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
                  }}
                >
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-gray-900 mb-1">
                    {t('contact.info.location')}
                  </h3>
                  <p className="text-gray-600">
                    {t('contact.info.locationValue')}
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
