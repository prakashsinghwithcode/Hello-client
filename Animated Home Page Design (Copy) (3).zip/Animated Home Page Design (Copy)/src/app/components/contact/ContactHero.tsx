import { motion } from "motion/react";
import { MessageCircle, Sparkles, FileText } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useQuote } from "@/contexts/QuoteContext";

export function ContactHero() {
  const { t } = useLanguage();
  const { isQuoteMode } = useQuote();

  return (
    <section className="relative min-h-[85vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20">
      {/* Animated Background Orbs */}
      <motion.div
        className="absolute top-20 left-[10%] w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{ background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))" }}
        animate={{
          y: [0, 50, 0],
          x: [0, 30, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 right-[10%] w-40 h-40 md:w-80 md:h-80 lg:w-[500px] lg:h-[500px] rounded-full blur-3xl opacity-20"
        style={{ background: "linear-gradient(135deg, rgb(6, 182, 212), rgb(79, 70, 229))" }}
        animate={{
          y: [0, -50, 0],
          x: [0, -30, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 grid lg:grid-cols-2 gap-12 items-center relative z-10">
        {/* Left: Text Content */}
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6"
            style={{ background: "linear-gradient(135deg, rgba(79, 70, 229, 0.1), rgba(147, 51, 234, 0.1))" }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            {isQuoteMode ? (
              <FileText className="w-5 h-5" style={{ color: "rgb(79, 70, 229)" }} />
            ) : (
              <Sparkles className="w-5 h-5" style={{ color: "rgb(79, 70, 229)" }} />
            )}
            <span style={{ color: "rgb(79, 70, 229)" }} className="font-semibold">
              {isQuoteMode ? "Custom Quote Request" : t('nav.contact')}
            </span>
          </motion.div>

          <motion.h1
            className="text-5xl md:text-7xl font-black mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234), rgb(6, 182, 212))",
              }}
            >
              {isQuoteMode ? "Request a Custom Quote" : t('contact.hero.title')}
            </span>
          </motion.h1>

          <motion.p
            className="text-xl md:text-2xl text-gray-600 leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            {isQuoteMode 
              ? "Tell us about your project and we'll prepare a personalized quote tailored to your needs."
              : t('contact.hero.subtitle')
            }
          </motion.p>
        </motion.div>

        {/* Right: Floating Illustration */}
        <motion.div
          className="relative h-[500px]"
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          {/* Central Chat Icon */}
          <motion.div
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-3xl flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(147, 51, 234))",
            }}
            animate={{
              y: [0, -20, 0],
              rotate: [0, 5, 0],
            }}
            transition={{
              duration: 4,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          >
            <MessageCircle className="w-24 h-24 text-white" />
          </motion.div>

          {/* Floating Gradient Shapes */}
          <motion.div
            className="absolute top-0 right-0 w-32 h-32 rounded-2xl"
            style={{
              background: "linear-gradient(135deg, rgb(6, 182, 212), rgb(79, 70, 229))",
            }}
            animate={{
              y: [0, 30, 0],
              rotate: [0, 10, 0],
            }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
          />
          <motion.div
            className="absolute bottom-20 left-10 w-40 h-40 rounded-2xl"
            style={{
              background: "linear-gradient(135deg, rgb(147, 51, 234), rgb(6, 182, 212))",
            }}
            animate={{
              y: [0, -25, 0],
              rotate: [0, -10, 0],
            }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 0.5,
            }}
          />
          <motion.div
            className="absolute top-40 left-0 w-24 h-24 rounded-xl"
            style={{
              background: "linear-gradient(135deg, rgb(79, 70, 229), rgb(6, 182, 212))",
            }}
            animate={{
              y: [0, 20, 0],
              x: [0, 15, 0],
              rotate: [0, 15, 0],
            }}
            transition={{
              duration: 7,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 1,
            }}
          />
        </motion.div>
      </div>
    </section>
  );
}