// Standalone SVG Logo Files for Export
// Tech-Startup Grade Logo - Clean, Bold, Scalable

export const LogoSVGFull = `
<svg width="240" height="50" viewBox="0 0 240 50" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Logo Icon -->
  <rect x="7" y="11" width="6" height="24" rx="1.5" fill="#3730A3"/>
  <rect x="27" y="11" width="6" height="24" rx="1.5" fill="#3730A3"/>
  <rect x="13" y="20" width="14" height="6" rx="1.5" fill="#3730A3"/>
  <circle cx="30" cy="14" r="1.5" fill="#06B6D4" opacity="0.4"/>
  <circle cx="20" cy="23" r="2" fill="#3730A3"/>
  
  <!-- Text -->
  <text x="48" y="32" font-family="system-ui, -apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="700" fill="#111827" letter-spacing="0.02em">
    Hello Client
  </text>
  <text x="185" y="32" font-family="system-ui, -apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="600" fill="#6B7280" letter-spacing="0.05em">
    .in
  </text>
</svg>
`;

export const LogoSVGIcon = `
<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Left vertical bar -->
  <rect x="7" y="8" width="6" height="24" rx="1.5" fill="#3730A3"/>
  
  <!-- Right vertical bar -->
  <rect x="27" y="8" width="6" height="24" rx="1.5" fill="#3730A3"/>
  
  <!-- Horizontal bridge -->
  <rect x="13" y="17" width="14" height="6" rx="1.5" fill="#3730A3"/>
  
  <!-- Subtle depth accent -->
  <circle cx="30" cy="11" r="1.5" fill="#06B6D4" opacity="0.4"/>
  
  <!-- Connection node -->
  <circle cx="20" cy="20" r="2" fill="#3730A3"/>
</svg>
`;

export const LogoSVGSquareGradient = `
<svg width="512" height="512" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bgGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#3730A3"/>
      <stop offset="50%" stop-color="#4F46E5"/>
      <stop offset="100%" stop-color="#06B6D4"/>
    </linearGradient>
  </defs>
  
  <!-- Background -->
  <rect width="512" height="512" rx="100" fill="url(#bgGradient)"/>
  
  <!-- Icon centered and sized at 55% -->
  <g transform="translate(115.2, 115.2) scale(7.04)">
    <rect x="7" y="8" width="6" height="24" rx="1.5" fill="#FFFFFF"/>
    <rect x="27" y="8" width="6" height="24" rx="1.5" fill="#FFFFFF"/>
    <rect x="13" y="17" width="14" height="6" rx="1.5" fill="#FFFFFF"/>
    <circle cx="30" cy="11" r="1.5" fill="#06B6D4" opacity="0.6"/>
    <circle cx="20" cy="20" r="2" fill="#FFFFFF"/>
  </g>
</svg>
`;

export const LogoSVGMonochromeDark = `
<svg width="240" height="50" viewBox="0 0 240 50" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Logo Icon -->
  <rect x="7" y="11" width="6" height="24" rx="1.5" fill="#111827"/>
  <rect x="27" y="11" width="6" height="24" rx="1.5" fill="#111827"/>
  <rect x="13" y="20" width="14" height="6" rx="1.5" fill="#111827"/>
  <circle cx="30" cy="14" r="1.5" fill="#111827" opacity="0.4"/>
  <circle cx="20" cy="23" r="2" fill="#111827"/>
  
  <!-- Text -->
  <text x="48" y="32" font-family="system-ui, -apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="700" fill="#111827" letter-spacing="0.02em">
    Hello Client
  </text>
  <text x="185" y="32" font-family="system-ui, -apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="600" fill="#6B7280" letter-spacing="0.05em">
    .in
  </text>
</svg>
`;

export const LogoSVGMonochromeLight = `
<svg width="240" height="50" viewBox="0 0 240 50" fill="none" xmlns="http://www.w3.org/2000/svg">
  <!-- Logo Icon -->
  <rect x="7" y="11" width="6" height="24" rx="1.5" fill="#FFFFFF"/>
  <rect x="27" y="11" width="6" height="24" rx="1.5" fill="#FFFFFF"/>
  <rect x="13" y="20" width="14" height="6" rx="1.5" fill="#FFFFFF"/>
  <circle cx="30" cy="14" r="1.5" fill="#FFFFFF" opacity="0.4"/>
  <circle cx="20" cy="23" r="2" fill="#FFFFFF"/>
  
  <!-- Text -->
  <text x="48" y="32" font-family="system-ui, -apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="700" fill="#FFFFFF" letter-spacing="0.02em">
    Hello Client
  </text>
  <text x="185" y="32" font-family="system-ui, -apple-system, BlinkMacSystemFont, sans-serif" font-size="22" font-weight="600" fill="#E5E7EB" letter-spacing="0.05em">
    .in
  </text>
</svg>
`;

// Helper function to download SVG files
export const downloadSVG = (svgContent: string, filename: string) => {
  const blob = new Blob([svgContent], { type: 'image/svg+xml' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

// Usage example:
// downloadSVG(LogoSVGFull, 'helloclient-logo-full.svg');
// downloadSVG(LogoSVGIcon, 'helloclient-icon-only.svg');
// downloadSVG(LogoSVGSquareGradient, 'helloclient-app-icon.svg');