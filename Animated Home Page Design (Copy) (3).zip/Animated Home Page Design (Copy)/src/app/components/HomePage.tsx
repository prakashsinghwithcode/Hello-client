import { HeroSlider } from "./HeroSlider";
import { ServicesSection } from "./ServicesSection";
import { WhyChooseUs } from "./WhyChooseUs";
import { FloatingCharacter } from "./FloatingCharacter";
import { Testimonials } from "./Testimonials";
import { Footer } from "./Footer";
import { StickyConsultationButton } from "./StickyConsultationButton";
import { SmoothScroll } from "./SmoothScroll";
import { PageTransition } from "./PageTransition";

export function HomePage() {
  return (
    <PageTransition>
      <SmoothScroll>
        <div className="relative overflow-x-hidden">
          {/* Hero Section with Animated Slider */}
          <HeroSlider />

          {/* Services Overview Section */}
          <ServicesSection />

          {/* Why Choose Us - Horizontal Scroll Section */}
          <WhyChooseUs />

          {/* Floating Character Section */}
          <FloatingCharacter />

          {/* Testimonials Section */}
          <Testimonials />

          {/* Footer */}
          <Footer />

          {/* Sticky Consultation Button */}
          <StickyConsultationButton />
        </div>
      </SmoothScroll>
    </PageTransition>
  );
}