import { motion, useInView } from "motion/react";
import { useRef } from "react";

interface ServiceOverviewProps {
  whatItIs: string;
  whoItsFor: string;
  problemItSolves: string;
}

export function ServiceOverview({
  whatItIs,
  whoItsFor,
  problemItSolves,
}: ServiceOverviewProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section className="relative py-24 bg-white" ref={ref}>
      <div className="max-w-5xl mx-auto px-4 md:px-8">
        <motion.h2
          className="text-4xl md:text-5xl font-black text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <span className="bg-gradient-to-r from-[#4F46E5] to-[#9333EA] bg-clip-text text-transparent">
            Service Overview
          </span>
        </motion.h2>

        <div className="space-y-12">
          {/* What It Is */}
          <motion.div
            className="relative p-8 rounded-3xl bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-gray-100"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-xl flex items-center justify-center text-white font-bold text-xl">
                ?
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3 text-gray-900">
                  What Is This Service?
                </h3>
                <p className="text-lg text-gray-700 leading-relaxed">
                  {whatItIs}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Who It's For */}
          <motion.div
            className="relative p-8 rounded-3xl bg-gradient-to-br from-purple-50 to-cyan-50 border-2 border-gray-100"
            initial={{ opacity: 0, x: 50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#9333EA] to-[#06B6D4] rounded-xl flex items-center justify-center text-white font-bold text-xl">
                👥
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3 text-gray-900">
                  Who Is This For?
                </h3>
                <p className="text-lg text-gray-700 leading-relaxed">
                  {whoItsFor}
                </p>
              </div>
            </div>
          </motion.div>

          {/* Problem It Solves */}
          <motion.div
            className="relative p-8 rounded-3xl bg-gradient-to-br from-cyan-50 to-blue-50 border-2 border-gray-100"
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#06B6D4] to-[#4F46E5] rounded-xl flex items-center justify-center text-white font-bold text-xl">
                ✓
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3 text-gray-900">
                  What Problem Does It Solve?
                </h3>
                <p className="text-lg text-gray-700 leading-relaxed">
                  {problemItSolves}
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
