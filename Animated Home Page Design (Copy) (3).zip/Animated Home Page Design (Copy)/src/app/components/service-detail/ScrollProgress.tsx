import { motion, useScroll, useTransform } from "motion/react";

export function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scrollTop = useTransform(scrollYProgress, [0, 1], ["0%", "100%"]);

  return (
    <motion.div
      className="fixed left-8 top-1/2 -translate-y-1/2 z-50 hidden lg:block"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 1 }}
    >
      <div className="relative">
        {/* Progress Bar Background */}
        <div className="w-1 h-64 bg-gray-200 rounded-full" />

        {/* Progress Bar Fill */}
        <motion.div
          className="absolute top-0 left-0 w-1 bg-gradient-to-b from-[#4F46E5] via-[#9333EA] to-[#06B6D4] rounded-full origin-top"
          style={{ scaleY: scrollYProgress }}
        />

        {/* Progress Indicator Dot */}
        <motion.div
          className="absolute left-1/2 -translate-x-1/2 w-4 h-4 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-full shadow-lg"
          style={{
            top: scrollTop,
          }}
        />
      </div>
    </motion.div>
  );
}