import { motion, useInView } from "motion/react";
import { useRef } from "react";

interface Tool {
  name: string;
  description: string;
  logo?: string;
}

interface ToolsTechProps {
  tools: Tool[];
}

export function ToolsTech({ tools }: ToolsTechProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section
      className="relative py-24 bg-gradient-to-br from-gray-50 to-purple-50"
      ref={ref}
    >
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="bg-gradient-to-r from-[#4F46E5] to-[#9333EA] bg-clip-text text-transparent">
              Tools & Technology
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Hum industry-best tools use karte hain
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {tools.map((tool, index) => (
            <motion.div
              key={index}
              className="group relative p-6 bg-white rounded-2xl shadow-lg border-2 border-gray-100 hover:border-[#4F46E5] transition-all duration-300"
              initial={{ opacity: 0, scale: 0.8, y: 50 }}
              animate={isInView ? { opacity: 1, scale: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              whileHover={{ y: -8, scale: 1.05 }}
            >
              {/* Tool Logo/Name */}
              <div className="flex flex-col items-center text-center">
                {tool.logo ? (
                  <div className="w-16 h-16 mb-4 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-xl flex items-center justify-center text-white font-bold text-2xl">
                    {tool.logo}
                  </div>
                ) : (
                  <div className="w-16 h-16 mb-4 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-xl flex items-center justify-center">
                    <div className="w-8 h-8 bg-white rounded-lg" />
                  </div>
                )}
                <h3 className="font-bold text-gray-900 mb-2 group-hover:text-[#4F46E5] transition-colors">
                  {tool.name}
                </h3>
                <p className="text-sm text-gray-600">{tool.description}</p>
              </div>

              {/* Hover Glow Effect - Using scale instead of opacity */}
              <div
                className="absolute inset-0 bg-gradient-to-r from-[#4F46E5]/10 to-[#9333EA]/10 rounded-2xl scale-0 group-hover:scale-100 transition-transform duration-300"
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}