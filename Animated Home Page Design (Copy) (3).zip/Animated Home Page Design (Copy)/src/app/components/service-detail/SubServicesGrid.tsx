import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight } from "lucide-react";

interface SubService {
  name: string;
  description: string;
}

interface SubServicesGridProps {
  subServices: SubService[];
}

export function SubServicesGrid({ subServices }: SubServicesGridProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section className="relative py-24 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="bg-gradient-to-r from-[#4F46E5] to-[#9333EA] bg-clip-text text-transparent">
              Sub-Services
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Is service mein kya kya include hai
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {subServices.map((service, index) => (
            <motion.div
              key={index}
              className="group relative p-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl border-2 border-gray-100 hover:border-[#4F46E5] transition-all duration-300 cursor-pointer"
              initial={{
                opacity: 0,
                y: 50,
                rotateY: -20,
              }}
              animate={isInView ? { opacity: 1, y: 0, rotateY: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{
                y: -5,
                boxShadow: "0 20px 40px rgba(79, 70, 229, 0.15)",
              }}
            >
              <h3 className="text-xl font-bold mb-3 text-gray-900 group-hover:text-[#4F46E5] transition-colors">
                {service.name}
              </h3>
              <p className="text-gray-600 mb-4 leading-relaxed">
                {service.description}
              </p>

              <motion.div
                className="inline-flex items-center gap-2 text-[#4F46E5] font-semibold group-hover:gap-3 transition-all"
                whileHover={{ x: 5 }}
              >
                <span className="text-sm">Learn More</span>
                <ArrowRight className="w-4 h-4" />
              </motion.div>

              {/* Animated Border */}
              <motion.div
                className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-[#4F46E5] to-[#9333EA]"
                initial={{ width: "0%" }}
                whileHover={{ width: "100%" }}
                transition={{ duration: 0.4 }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
