import { motion, useInView } from "motion/react";
import { useRef } from "react";

interface Step {
  number: number;
  title: string;
  description: string;
}

interface OurApproachProps {
  steps: Step[];
}

export function OurApproach({ steps }: OurApproachProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section className="relative py-24 bg-white" ref={ref}>
      <div className="max-w-6xl mx-auto px-4 md:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="bg-gradient-to-r from-[#4F46E5] to-[#9333EA] bg-clip-text text-transparent">
              Our Approach
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Hum kaise kaam karte hain - Step by Step
          </p>
        </motion.div>

        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-1 bg-gradient-to-b from-[#4F46E5] via-[#9333EA] to-[#06B6D4] transform -translate-x-1/2" />

          <div className="space-y-16">
            {steps.map((step, index) => {
              const isEven = index % 2 === 0;

              return (
                <motion.div
                  key={index}
                  className={`relative flex flex-col lg:flex-row items-center gap-8 ${
                    isEven ? "lg:flex-row" : "lg:flex-row-reverse"
                  }`}
                  initial={{
                    opacity: 0,
                    x: isEven ? -100 : 100,
                    y: 50,
                  }}
                  animate={isInView ? { opacity: 1, x: 0, y: 0 } : {}}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                >
                  {/* Step Card */}
                  <motion.div
                    className="flex-1 p-8 bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl border-2 border-gray-100 shadow-lg"
                    whileHover={{
                      scale: 1.03,
                      boxShadow: "0 20px 40px rgba(79, 70, 229, 0.15)",
                    }}
                  >
                    <h3 className="text-2xl font-bold mb-3 text-gray-900">
                      {step.title}
                    </h3>
                    <p className="text-lg text-gray-700 leading-relaxed">
                      {step.description}
                    </p>
                  </motion.div>

                  {/* Step Number Circle */}
                  <motion.div
                    className="flex-shrink-0 w-20 h-20 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-full flex items-center justify-center text-white font-black text-3xl shadow-2xl relative z-10"
                    whileHover={{ scale: 1.2, rotate: 360 }}
                    transition={{ duration: 0.6 }}
                  >
                    {step.number}
                  </motion.div>

                  {/* Spacer for alignment */}
                  <div className="hidden lg:block flex-1" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
