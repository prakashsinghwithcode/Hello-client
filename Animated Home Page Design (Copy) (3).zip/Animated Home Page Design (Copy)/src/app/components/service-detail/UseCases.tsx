import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { LucideIcon } from "lucide-react";

interface UseCase {
  icon: LucideIcon;
  businessType: string;
  howItHelps: string;
}

interface UseCasesProps {
  useCases: UseCase[];
}

export function UseCases({ useCases }: UseCasesProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section
      className="relative py-24 bg-gradient-to-br from-blue-50 to-cyan-50"
      ref={ref}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="bg-gradient-to-r from-[#4F46E5] to-[#9333EA] bg-clip-text text-transparent">
              Use Cases & Examples
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Different businesses ke liye kaise useful hai
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {useCases.map((useCase, index) => {
            const Icon = useCase.icon;
            return (
              <motion.div
                key={index}
                className="relative group"
                initial={{
                  opacity: 0,
                  y: 100,
                  rotateX: 45,
                }}
                animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
                transition={{
                  duration: 0.8,
                  delay: index * 0.15,
                  ease: "easeOut",
                }}
              >
                <div className="h-full p-8 bg-white rounded-3xl shadow-xl border-2 border-gray-100 overflow-hidden">
                  {/* Icon Circle */}
                  <motion.div
                    className="w-20 h-20 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-full flex items-center justify-center mb-6 shadow-lg"
                    whileHover={{
                      scale: 1.2,
                      rotate: [0, -10, 10, -10, 0],
                    }}
                    transition={{ duration: 0.5 }}
                  >
                    <Icon className="w-10 h-10 text-white" />
                  </motion.div>

                  {/* Business Type */}
                  <h3 className="text-2xl font-bold mb-4 text-gray-900 group-hover:text-[#4F46E5] transition-colors">
                    {useCase.businessType}
                  </h3>

                  {/* How It Helps */}
                  <p className="text-gray-600 leading-relaxed">
                    {useCase.howItHelps}
                  </p>

                  {/* Decorative Element - Using scale instead of opacity */}
                  <motion.div
                    className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#4F46E5]/5 to-[#9333EA]/5 rounded-full blur-2xl scale-0 group-hover:scale-100 transition-transform duration-500"
                    animate={{
                      scale: [1, 1.2, 1],
                    }}
                    transition={{
                      duration: 3,
                      repeat: Infinity,
                    }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}