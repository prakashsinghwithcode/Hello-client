import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { LucideIcon } from "lucide-react";

interface Benefit {
  icon: LucideIcon;
  title: string;
  description: string;
}

interface BusinessBenefitsProps {
  benefits: Benefit[];
}

export function BusinessBenefits({ benefits }: BusinessBenefitsProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section
      className="relative py-24 bg-gradient-to-br from-gray-50 to-blue-50 overflow-hidden"
      ref={ref}
    >
      {/* Background Decorative Elements */}
      <motion.div
        className="absolute top-20 right-10 w-64 h-64 bg-gradient-to-r from-[#4F46E5]/10 to-[#9333EA]/10 rounded-full blur-3xl"
        animate={{ scale: [1, 1.2, 1], rotate: [0, 90, 0] }}
        transition={{ duration: 10, repeat: Infinity }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4">
            <span className="bg-gradient-to-r from-[#4F46E5] to-[#9333EA] bg-clip-text text-transparent">
              Business Benefits
            </span>
          </h2>
          <p className="text-xl text-gray-600">
            Aapke business ko kaise faayda hoga
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <motion.div
                key={index}
                className="group relative"
                initial={{ opacity: 0, y: 50, rotateX: -15 }}
                animate={isInView ? { opacity: 1, y: 0, rotateX: 0 } : {}}
                transition={{
                  duration: 0.6,
                  delay: index * 0.1,
                  ease: "easeOut",
                }}
                whileHover={{ y: -10, scale: 1.02 }}
              >
                <div className="relative h-full p-8 bg-white rounded-3xl shadow-lg border-2 border-gray-100 overflow-hidden">
                  {/* Gradient Background on Hover - Using fixed low opacity to avoid animation issues */}
                  <div className="absolute inset-0 bg-gradient-to-br from-[#4F46E5]/5 to-[#9333EA]/5 group-hover:from-[#4F46E5]/10 group-hover:to-[#9333EA]/10 transition-all duration-300" />

                  {/* Icon */}
                  <motion.div
                    className="relative w-16 h-16 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] rounded-2xl flex items-center justify-center mb-6 shadow-lg"
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Content */}
                  <h3 className="relative text-2xl font-bold mb-3 text-gray-900 group-hover:text-[#4F46E5] transition-colors duration-300">
                    {benefit.title}
                  </h3>
                  <p className="relative text-gray-600 leading-relaxed">
                    {benefit.description}
                  </p>

                  {/* Bottom Accent Line */}
                  <motion.div
                    className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-[#4F46E5] to-[#9333EA]"
                    initial={{ width: "0%" }}
                    whileInView={{ width: "100%" }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, delay: index * 0.1 }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}