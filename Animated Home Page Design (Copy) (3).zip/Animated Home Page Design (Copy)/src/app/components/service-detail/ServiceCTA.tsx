import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { ArrowRight, Phone } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useQuote } from "@/contexts/QuoteContext";

export function ServiceCTA() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const navigate = useNavigate();
  const location = useLocation();
  const { setQuoteMode } = useQuote();

  const handleGetQuote = () => {
    // Extract service name from current path
    const pathParts = location.pathname.split('/');
    const serviceName = pathParts[pathParts.length - 1];
    
    // Map path to service value
    const serviceMap: Record<string, string> = {
      'marketing': 'marketing',
      'web-development': 'web',
      'app-development': 'app',
      'marketing-design': 'design',
      'corporate-design': 'design',
      'catalogue-design': 'design',
      'digital-templates': 'design',
      'branding': 'branding',
    };
    
    const service = serviceMap[serviceName] || 'other';
    setQuoteMode(true, service);
    navigate('/contact');
  };

  return (
    <section
      className="relative py-24 overflow-hidden bg-gradient-to-br from-[#4F46E5] via-[#9333EA] to-[#06B6D4]"
      ref={ref}
    >
      {/* Animated Background Pattern */}
      <motion.div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle, white 1px, transparent 1px)`,
          backgroundSize: "30px 30px",
        }}
        animate={{
          backgroundPosition: ["0px 0px", "30px 30px"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Floating Orbs */}
      <motion.div
        className="absolute top-10 left-10 w-64 h-64 bg-white/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.3, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{ duration: 8, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-10 right-10 w-96 h-96 bg-white/10 rounded-full blur-3xl"
        animate={{
          scale: [1, 1.4, 1],
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{ duration: 10, repeat: Infinity }}
      />

      <div className="max-w-5xl mx-auto px-4 md:px-8 relative z-10">
        <motion.div
          className="text-center"
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-block px-6 py-2 bg-white/20 backdrop-blur-sm rounded-full mb-8"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={isInView ? { scale: 1, opacity: 1 } : {}}
            transition={{ duration: 0.6 }}
          >
            <span className="text-white font-semibold">
              ✨ Ready to Transform Your Business?
            </span>
          </motion.div>

          <motion.h2
            className="text-4xl md:text-6xl font-black text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Ready to Grow with This Service?
          </motion.h2>

          <motion.p
            className="text-xl md:text-2xl text-white/90 mb-12 leading-relaxed max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            Apne business ko next level par le jaayein. Humari expert team aapki
            help ke liye ready hai.
          </motion.p>

          <motion.div
            className="flex flex-col sm:flex-row gap-6 justify-center items-center"
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            {/* Primary CTA */}
            <motion.button
              className="group px-10 py-5 bg-white text-[#4F46E5] font-bold rounded-full shadow-2xl text-lg flex items-center gap-3"
              whileHover={{
                scale: 1.05,
                boxShadow: "0 30px 60px rgba(0, 0, 0, 0.3)",
              }}
              whileTap={{ scale: 0.95 }}
              onClick={handleGetQuote}
            >
              <span>Start This Service</span>
              <motion.div
                animate={{ x: [0, 5, 0] }}
                transition={{ duration: 1, repeat: Infinity }}
              >
                <ArrowRight className="w-6 h-6" />
              </motion.div>
            </motion.button>

            {/* Secondary CTA */}
            <motion.button
              className="group px-10 py-5 bg-white/10 backdrop-blur-sm text-white font-bold rounded-full border-2 border-white/30 text-lg flex items-center gap-3"
              whileHover={{
                scale: 1.05,
                backgroundColor: "rgba(255, 255, 255, 0.2)",
                borderColor: "rgba(255, 255, 255, 0.5)",
              }}
              whileTap={{ scale: 0.95 }}
              onClick={() => navigate("/contact")}
            >
              <Phone className="w-6 h-6" />
              <span>Talk to Expert</span>
            </motion.button>
          </motion.div>

          {/* Trust Badge */}
          <motion.div
            className="mt-12 flex flex-wrap justify-center items-center gap-8 text-white/80"
            initial={{ opacity: 0 }}
            animate={isInView ? { opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="font-semibold">500+ Happy Clients</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="font-semibold">24/7 Support</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              <span className="font-semibold">100% Satisfaction</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}