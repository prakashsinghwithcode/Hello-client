import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { LucideIcon } from "lucide-react";

interface ServiceHeroProps {
  title: string;
  tagline: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
}

export function ServiceHero({
  title,
  tagline,
  description,
  icon: Icon,
  gradient,
}: ServiceHeroProps) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section
      ref={ref}
      className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20"
    >
      {/* Animated Background Pattern */}
      <motion.div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle, #4F46E5 1px, transparent 1px)`,
          backgroundSize: "40px 40px",
        }}
        animate={{
          backgroundPosition: ["0px 0px", "40px 40px"],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Floating Gradient Orbs */}
      <motion.div
        className={`absolute top-20 left-[10%] w-96 h-96 rounded-full blur-3xl opacity-20 bg-gradient-to-r ${gradient}`}
        animate={{
          y: [0, 50, 0],
          x: [0, 30, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className={`absolute bottom-20 right-[10%] w-40 h-40 md:w-80 md:h-80 lg:w-[500px] lg:h-[500px] rounded-full blur-3xl opacity-20 bg-gradient-to-r ${gradient}`}
        animate={{
          y: [0, -50, 0],
          x: [0, -30, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="max-w-6xl mx-auto px-4 md:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Content */}
          <div>
            <motion.div
              className={`inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r ${gradient} rounded-2xl mb-6 shadow-2xl`}
              initial={{ opacity: 0, scale: 0.5, rotate: -180 }}
              animate={isInView ? { opacity: 1, scale: 1, rotate: 0 } : {}}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <Icon className="w-10 h-10 text-white" />
            </motion.div>

            <motion.h1
              className="text-5xl md:text-7xl font-black mb-4"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <span
                className={`bg-gradient-to-r ${gradient} bg-clip-text text-transparent`}
              >
                {title}
              </span>
            </motion.h1>

            <motion.p
              className="text-2xl md:text-3xl font-bold text-gray-900 mb-6"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              {tagline}
            </motion.p>

            <motion.p
              className="text-xl text-gray-600 leading-relaxed"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              {description}
            </motion.p>
          </div>

          {/* Right: Visual Illustration */}
          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 100, scale: 0.8 }}
            animate={isInView ? { opacity: 1, x: 0, scale: 1 } : {}}
            transition={{ duration: 1, delay: 0.5 }}
          >
            <div className="relative">
              {/* Main Icon Display */}
              <motion.div
                className={`w-full aspect-square bg-gradient-to-br ${gradient} rounded-[3rem] shadow-2xl flex items-center justify-center`}
                animate={{
                  boxShadow: [
                    "0 25px 50px rgba(79, 70, 229, 0.3)",
                    "0 35px 70px rgba(147, 51, 234, 0.4)",
                    "0 25px 50px rgba(79, 70, 229, 0.3)",
                  ],
                }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <Icon className="w-48 h-48 text-white" strokeWidth={1.5} />
              </motion.div>

              {/* Floating Elements */}
              <motion.div
                className={`absolute -top-6 -right-6 w-24 h-24 bg-gradient-to-r ${gradient} rounded-2xl shadow-xl`}
                animate={{
                  rotate: [0, 360],
                  scale: [1, 1.1, 1],
                }}
                transition={{ duration: 6, repeat: Infinity }}
              />
              <motion.div
                className={`absolute -bottom-6 -left-6 w-32 h-32 rounded-full blur-2xl`}
                style={{
                  background: `linear-gradient(to right, rgb(79, 70, 229), rgb(147, 51, 234))`,
                }}
                animate={{
                  scale: [1, 1.3, 1],
                  opacity: [0.4, 0.5, 0.4],
                }}
                transition={{ duration: 4, repeat: Infinity }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}