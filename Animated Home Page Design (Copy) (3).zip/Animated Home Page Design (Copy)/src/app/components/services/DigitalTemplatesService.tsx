import { motion } from "motion/react";
import {
  FileText,
  Zap,
  Clock,
  TrendingUp,
  Award,
  Users,
  Store,
  Building2,
  Briefcase,
  GraduationCap,
  Heart,
  Rocket,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function DigitalTemplatesService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="Digital Templates"
        tagline="Ready-to-Use Templates That Save Your Time"
        description="From email templates to presentation decks - all digital templates that are professional and instantly usable."
        icon={FileText}
        gradient="from-[#4F46E5] to-[#9333EA]"
      />

      <ServiceOverview
        whatItIs="Our Digital Templates service creates reusable design templates - email newsletters, social media templates, presentation decks, and document templates. You can use them repeatedly, simply changing the content."
        whoItsFor="Businesses that create emails, presentations, or documents regularly. Startups, marketing teams, sales teams - anyone who wants to save time and maintain consistent branding."
        problemItSolves="Designing from scratch every time is time-consuming. When different team members use different designs, branding becomes inconsistent. Templates let you quickly create professional materials with zero design skills."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: Zap,
            title: "Lightning Fast",
            description:
              "Create professional materials in minutes - hours of work done in minutes",
          },
          {
            icon: Clock,
            title: "Save Time",
            description:
              "Save design time for every email and presentation - focus on content, not design",
          },
          {
            icon: Award,
            title: "Brand Consistency",
            description:
              "Consistent branding is automatically maintained in every document",
          },
          {
            icon: Users,
            title: "Team Efficiency",
            description:
              "Your entire team uses the same templates - no design skills required",
          },
          {
            icon: TrendingUp,
            title: "Professional Output",
            description:
              "Consistently professional-quality materials without hiring designers",
          },
          {
            icon: Zap,
            title: "Easy Updates",
            description:
              "Easily update templates - change content, design stays automatic",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Usage Analysis",
            description:
              "We analyze what templates you need, how often they'll be used, and for what purpose.",
          },
          {
            number: 2,
            title: "Template Design",
            description:
              "We design templates according to brand guidelines and create multiple variations for different use cases.",
          },
          {
            number: 3,
            title: "Flexibility Building",
            description:
              "We make templates flexible so you can easily customize them. Colors, images, text - all editable.",
          },
          {
            number: 4,
            title: "Documentation",
            description:
              "We create simple guidelines for using templates, explaining how to edit and what can be changed.",
          },
          {
            number: 5,
            title: "Delivery & Training",
            description:
              "We deliver templates with quick training, showing your team how to use them.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "Canva Pro", description: "Easy Templates", logo: "C" },
          { name: "PowerPoint", description: "Presentations", logo: "PP" },
          { name: "Google Slides", description: "Cloud Presentations", logo: "GS" },
          { name: "Figma", description: "Design System", logo: "F" },
          { name: "Mailchimp", description: "Email Templates", logo: "MC" },
          { name: "Adobe XD", description: "UI Templates", logo: "XD" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "Email Newsletter Templates",
            description:
              "Professional email templates for marketing, updates, announcements - fully responsive",
          },
          {
            name: "Social Media Templates",
            description:
              "Instagram, Facebook, LinkedIn post templates - consistent social media presence",
          },
          {
            name: "Presentation Decks",
            description:
              "PowerPoint/Google Slides templates for pitches, reports, training sessions",
          },
          {
            name: "Document Templates",
            description:
              "Word templates for proposals, reports, invoices, and quotations",
          },
          {
            name: "Social Media Story Templates",
            description:
              "Instagram/Facebook Stories templates for quick daily updates",
          },
          {
            name: "Landing Page Templates",
            description:
              "Website landing page templates for campaigns and product launches",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: Store,
            businessType: "E-commerce",
            howItHelps:
              "Email templates for order confirmations, shipping updates, and promotional campaigns. Every email is branded and professional.",
          },
          {
            icon: Building2,
            businessType: "Corporate/Enterprise",
            howItHelps:
              "Presentation templates for client meetings and internal reports. Consistent corporate identity across all materials.",
          },
          {
            icon: Briefcase,
            businessType: "Marketing Agencies",
            howItHelps:
              "Social media templates for multiple clients. Quick turnaround time for daily posts.",
          },
          {
            icon: Rocket,
            businessType: "Startups",
            howItHelps:
              "Pitch deck templates for investor presentations. Professional materials without a full-time designer.",
          },
          {
            icon: GraduationCap,
            businessType: "Educational Institutes",
            howItHelps:
              "Announcement templates and course material templates. Quick communication with students and parents.",
          },
          {
            icon: Heart,
            businessType: "Healthcare",
            howItHelps:
              "Appointment reminder templates and health tips newsletters. Easy regular patient communication.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}