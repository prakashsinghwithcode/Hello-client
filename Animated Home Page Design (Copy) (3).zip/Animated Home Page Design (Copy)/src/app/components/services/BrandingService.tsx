import { motion } from "motion/react";
import {
  Award,
  Target,
  Eye,
  TrendingUp,
  Users,
  Zap,
  Store,
  Rocket,
  GraduationCap,
  Heart,
  Coffee,
  Building2,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function BrandingService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="Branding Kit"
        tagline="Complete Brand Identity That Makes Your Business Unforgettable"
        description="From logo to complete brand guidelines - every element that makes your brand unique and memorable."
        icon={Award}
        gradient="from-[#9333EA] to-[#06B6D4]"
      />

      <ServiceOverview
        whatItIs="Our Branding Kit creates a complete brand identity for your business - logo design, color palette, typography system, brand voice, and usage guidelines. These elements combine to form your unique brand personality."
        whoItsFor="New startups building their brand identity, established businesses looking to rebrand, or any business wanting to strengthen their brand image. Strong branding is the foundation of every successful business."
        problemItSolves="Without proper branding, businesses look generic and customers don't remember them. Inconsistent brand usage damages professional image. A complete branding kit makes your business memorable and maintains consistent identity across all touchpoints."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: Eye,
            title: "Memorable Identity",
            description:
              "A unique brand identity helps customers easily recognize and remember you",
          },
          {
            icon: Target,
            title: "Stand Out",
            description:
              "Strong brand identity differentiates you from competitors - establish your unique market position",
          },
          {
            icon: TrendingUp,
            title: "Increase Value",
            description:
              "Strong branding increases brand value and customer loyalty - enables premium pricing",
          },
          {
            icon: Users,
            title: "Build Trust",
            description:
              "Professional branding builds customer trust - you appear established and reliable",
          },
          {
            icon: Zap,
            title: "Consistency",
            description:
              "Brand guidelines ensure consistent identity across all platforms",
          },
          {
            icon: Award,
            title: "Professional Image",
            description:
              "Complete branding transforms you from a small startup to a professional business",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Brand Discovery",
            description:
              "We deeply understand your business vision, values, and target audience. We analyze competitors and identify your unique positioning.",
          },
          {
            number: 2,
            title: "Strategy Development",
            description:
              "We create a brand strategy - what message to convey, desired personality, and target audience definition.",
          },
          {
            number: 3,
            title: "Visual Identity Creation",
            description:
              "We create logo concepts, explore color palettes, and select typography. We present multiple options for your review.",
          },
          {
            number: 4,
            title: "Brand Guidelines",
            description:
              "We create a complete brand guidelines document - logo usage, color codes, font specifications, dos and don'ts.",
          },
          {
            number: 5,
            title: "Brand Rollout",
            description:
              "We deliver the complete branding kit with all file formats and provide implementation support.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "Adobe Illustrator", description: "Logo Design", logo: "AI" },
          { name: "Photoshop", description: "Visual Mockups", logo: "PS" },
          { name: "Figma", description: "Design System", logo: "F" },
          { name: "InDesign", description: "Guidelines Doc", logo: "ID" },
          { name: "Procreate", description: "Sketching", logo: "P" },
          { name: "After Effects", description: "Logo Animation", logo: "AE" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "Logo Design",
            description:
              "Unique, memorable logo design with multiple variations - full color, monochrome, icon only",
          },
          {
            name: "Brand Color Palette",
            description:
              "Custom color scheme with primary and secondary colors - specific HEX/RGB/CMYK codes",
          },
          {
            name: "Typography System",
            description:
              "Font selection for headings and body text - with usage guidelines and alternatives",
          },
          {
            name: "Brand Guidelines",
            description:
              "Comprehensive document with all brand usage rules, dos and don'ts, and examples",
          },
          {
            name: "Brand Collaterals",
            description:
              "Business cards, letterheads, social media profiles - initial branded materials",
          },
          {
            name: "Brand Voice & Messaging",
            description:
              "Communication tone, key messages, taglines - verbal identity guidelines",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: Rocket,
            businessType: "New Startups",
            howItHelps:
              "Ground-up brand identity creation. Get strong branding ready before launch for a professional start.",
          },
          {
            icon: Store,
            businessType: "Retail/E-commerce",
            howItHelps:
              "Memorable brand identity consistent across packaging, store design, and online presence. Build brand loyalty.",
          },
          {
            icon: Coffee,
            businessType: "F&B/Restaurants",
            howItHelps:
              "Distinctive brand personality reflected in menu, packaging, and interior design. Instagram-worthy branding.",
          },
          {
            icon: GraduationCap,
            businessType: "Educational Institutes",
            howItHelps:
              "Trust-building brand identity. Memorable logo with consistent usage across all materials.",
          },
          {
            icon: Heart,
            businessType: "Healthcare/Wellness",
            howItHelps:
              "Caring yet professional brand identity. Clean, trustworthy branding that provides patient comfort.",
          },
          {
            icon: Building2,
            businessType: "B2B Services",
            howItHelps:
              "Corporate yet approachable branding. Professional identity that impresses business clients.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}