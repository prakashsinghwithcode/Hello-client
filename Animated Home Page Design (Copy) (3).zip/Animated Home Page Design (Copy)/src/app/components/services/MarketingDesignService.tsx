import { motion } from "motion/react";
import {
  Palette,
  Eye,
  TrendingUp,
  Share2,
  Award,
  Zap,
  Store,
  GraduationCap,
  Building2,
  Rocket,
  Coffee,
  Heart,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function MarketingDesignService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="Marketing Design"
        tagline="Eye-Catching Designs That Attract Customers"
        description="From social media graphics to ad banners - all types of marketing materials that make your brand shine."
        icon={Palette}
        gradient="from-[#4F46E5] to-[#9333EA]"
      />

      <ServiceOverview
        whatItIs="Our Marketing Design services create social media posts, ad banners, infographics, presentation decks, and promotional materials. Every design is eye-catching, on-brand, and message-focused to instantly grab your audience's attention."
        whoItsFor="Any business active on social media or running marketing campaigns. Whether you need daily posts, ad creatives, or special campaign materials - this service covers all your marketing design needs."
        problemItSolves="Boring or unprofessional designs don't attract customers. When scrolling through social media, only great designs catch attention. We create designs that stop the scroll and generate clicks."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: Eye,
            title: "Grab Attention",
            description:
              "Professional designs instantly grab attention and engage your audience",
          },
          {
            icon: Share2,
            title: "Increase Engagement",
            description:
              "Attractive visuals boost likes, comments, and shares - up to 5x better engagement",
          },
          {
            icon: TrendingUp,
            title: "Better Conversions",
            description:
              "Well-designed ads significantly improve click-through rates and conversion rates",
          },
          {
            icon: Award,
            title: "Professional Brand Image",
            description:
              "Consistent, high-quality designs make your brand appear professional and trustworthy",
          },
          {
            icon: Zap,
            title: "Quick Turnaround",
            description:
              "Ready-made templates and fast design processes deliver designs quickly",
          },
          {
            icon: Share2,
            title: "Multi-Platform Ready",
            description:
              "Designs optimized for every platform - Instagram, Facebook, LinkedIn, and more",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Brief & Requirements",
            description:
              "We understand your marketing goals, target audience, and brand guidelines. We discuss what message to convey and which platforms to target.",
          },
          {
            number: 2,
            title: "Concept Creation",
            description:
              "We create 2-3 design concepts and try different styles and approaches to find the perfect look.",
          },
          {
            number: 3,
            title: "Design Development",
            description:
              "We refine the approved concept, perfecting colors, typography, and imagery.",
          },
          {
            number: 4,
            title: "Revisions & Finalization",
            description:
              "We gather your feedback and make necessary changes. We continue revisions until you're completely satisfied.",
          },
          {
            number: 5,
            title: "Delivery & Formats",
            description:
              "We deliver final designs in multiple formats - print, web, social media - ready for any use.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "Adobe Photoshop", description: "Image Editing", logo: "PS" },
          { name: "Adobe Illustrator", description: "Vector Graphics", logo: "AI" },
          { name: "Canva Pro", description: "Quick Designs", logo: "C" },
          { name: "Figma", description: "UI/UX Design", logo: "F" },
          { name: "After Effects", description: "Motion Graphics", logo: "AE" },
          { name: "InDesign", description: "Layout Design", logo: "ID" },
          { name: "Premiere Pro", description: "Video Editing", logo: "PR" },
          { name: "CorelDRAW", description: "Vector Design", logo: "CD" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "Social Media Graphics",
            description:
              "Instagram posts, Facebook covers, LinkedIn banners - designs optimized for every platform",
          },
          {
            name: "Ad Banners & Creatives",
            description:
              "Google Display Ads, Facebook Ads, YouTube thumbnails - high-converting ad creatives",
          },
          {
            name: "Infographics",
            description:
              "Convert complex information into visually attractive and easy-to-understand infographics",
          },
          {
            name: "Presentation Decks",
            description:
              "Professional PowerPoint/Keynote presentations that impress clients and investors",
          },
          {
            name: "Email Templates",
            description:
              "Beautiful email newsletter designs that stand out in inboxes and drive clicks",
          },
          {
            name: "Marketing Collaterals",
            description:
              "Flyers, posters, banners, standees - all types of promotional materials",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: Store,
            businessType: "E-commerce/Retail",
            howItHelps:
              "Product showcase posts, sale announcements, promotional banners. Attractive visuals make products appealing and boost sales.",
          },
          {
            icon: GraduationCap,
            businessType: "Educational Institute",
            howItHelps:
              "Course promotion graphics, admission announcements, achievement posts. Professional materials attract students and parents.",
          },
          {
            icon: Building2,
            businessType: "Real Estate",
            howItHelps:
              "Property showcase designs, project brochures, comparison infographics. Properties presented in visually appealing ways.",
          },
          {
            icon: Rocket,
            businessType: "Startups/Tech",
            howItHelps:
              "Pitch decks, feature announcements, product launches. Modern designs make startups appear professional and innovative.",
          },
          {
            icon: Coffee,
            businessType: "F&B/Restaurant",
            howItHelps:
              "Menu designs, food photography posts, offer graphics. Mouth-watering visuals attract customers.",
          },
          {
            icon: Heart,
            businessType: "Healthcare/Wellness",
            howItHelps:
              "Health tips infographics, appointment reminders, service promotions. Trust-building designs that appear professional and caring.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}