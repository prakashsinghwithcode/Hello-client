import { motion } from "motion/react";
import {
  Globe,
  Zap,
  Shield,
  Smartphone,
  TrendingUp,
  Award,
  Store,
  GraduationCap,
  UtensilsCrossed,
  Briefcase,
  Heart,
  Home,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function WebDevelopmentService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="Website Development"
        tagline="Create the Perfect Website for Your Business"
        description="Modern, fast, and mobile-friendly websites that impress customers and drive sales growth."
        icon={Globe}
        gradient="from-[#9333EA] to-[#06B6D4]"
      />

      <ServiceOverview
        whatItIs="Our Website Development services include custom websites, e-commerce stores, landing pages, and web applications. Every website features modern design, fast loading speeds, mobile responsiveness, and SEO optimization."
        whoItsFor="Any business looking to establish an online presence - whether you're a startup, established company, or individual professional. If you don't have a website or need to upgrade an outdated one, this service is for you."
        problemItSolves="In today's digital age, not having a website means losing customer trust. Old websites are slow and don't display properly on mobile devices. We create websites that are fast, beautiful, and sales-focused."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: TrendingUp,
            title: "Increase Sales",
            description:
              "A professional website builds customer trust and can improve conversion rates by up to 60%",
          },
          {
            icon: Shield,
            title: "Build Brand Trust",
            description:
              "A modern website makes customers perceive you as professional and trustworthy",
          },
          {
            icon: Smartphone,
            title: "Mobile-Friendly",
            description:
              "80% of users browse on mobile - our websites look perfect on every screen size",
          },
          {
            icon: Zap,
            title: "Lightning Fast",
            description:
              "Super fast loading speeds ensure customers get information instantly and reduce bounce rates",
          },
          {
            icon: Globe,
            title: "24/7 Availability",
            description:
              "Your website serves customers around the clock, without any breaks",
          },
          {
            icon: Award,
            title: "SEO Ready",
            description:
              "Built-in SEO optimization helps you rank higher on Google search results",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Requirement Gathering",
            description:
              "We start by understanding your business, goals, and target audience. We discuss what features you need and what design style you prefer.",
          },
          {
            number: 2,
            title: "Design & Mockup",
            description:
              "We create visual designs for your website and share mockups with you so you can see how the final website will look.",
          },
          {
            number: 3,
            title: "Development",
            description:
              "After design approval, we begin the actual coding process. We use the latest technologies to develop a fast and secure website.",
          },
          {
            number: 4,
            title: "Testing & Review",
            description:
              "Once the website is ready, we test everything - speed, mobile responsiveness, and all features. We share it with you for review.",
          },
          {
            number: 5,
            title: "Launch & Support",
            description:
              "After final approval, we launch your website. We provide ongoing support for any updates or issues that may arise.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "React", description: "Modern UI Framework", logo: "R" },
          { name: "Next.js", description: "Full-stack Framework", logo: "N" },
          { name: "WordPress", description: "CMS Platform", logo: "W" },
          { name: "Shopify", description: "E-commerce Platform", logo: "S" },
          { name: "Tailwind CSS", description: "Styling Framework", logo: "T" },
          { name: "Node.js", description: "Backend Runtime", logo: "NJ" },
          { name: "MongoDB", description: "Database", logo: "M" },
          { name: "Figma", description: "Design Tool", logo: "F" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "Business Websites",
            description:
              "Professional corporate websites with complete business information, services, portfolio, and contact forms",
          },
          {
            name: "E-commerce Stores",
            description:
              "Online shopping websites with cart, payment gateway, inventory management, and order tracking",
          },
          {
            name: "Landing Pages",
            description:
              "High-converting single pages for specific campaigns, product launches, and lead generation",
          },
          {
            name: "Custom Web Apps",
            description:
              "Custom web applications tailored to your specific business needs - CRM systems, dashboards, booking platforms",
          },
          {
            name: "WordPress Sites",
            description:
              "Easy-to-manage WordPress websites where you can update content yourself",
          },
          {
            name: "Website Redesign",
            description:
              "Transform outdated websites into modern, fast, and mobile-friendly platforms",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: Store,
            businessType: "Retail/E-commerce",
            howItHelps:
              "Full-featured online store with cart, payments, and inventory management. Customers can shop 24/7 and your reach expands nationwide.",
          },
          {
            icon: GraduationCap,
            businessType: "Educational Institute",
            howItHelps:
              "Course catalog, online admissions, and student portal. Parents and students can easily access complete information.",
          },
          {
            icon: UtensilsCrossed,
            businessType: "Restaurant/Cafe",
            howItHelps:
              "Digital menu, online ordering, and table booking. Customers can place orders directly from your website and request delivery.",
          },
          {
            icon: Briefcase,
            businessType: "Professional Services",
            howItHelps:
              "Portfolio showcase, client testimonials, and appointment booking. Professionals can present their expertise and work samples effectively.",
          },
          {
            icon: Heart,
            businessType: "Healthcare/Clinic",
            howItHelps:
              "Doctor profiles, online appointment booking, and health tips blog. Patients can easily schedule appointments online.",
          },
          {
            icon: Home,
            businessType: "Real Estate",
            howItHelps:
              "Property listings with filters, virtual tours, and inquiry forms. Buyers can easily browse properties and make contact.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}