import { motion } from "motion/react";
import { Sparkles } from "lucide-react";

export function ServicesHero() {
  return (
    <section className="relative min-h-[70vh] flex items-center justify-center overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50 pt-20">
      {/* Animated Background Pattern */}
      <motion.div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `radial-gradient(circle, #4F46E5 1px, transparent 1px)`,
          backgroundSize: "30px 30px",
        }}
        animate={{
          backgroundPosition: ["0px 0px", "30px 30px"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      {/* Floating Gradient Orbs */}
      <motion.div
        className="absolute top-20 left-[15%] w-72 h-72 rounded-full blur-3xl opacity-20"
        style={{ background: "linear-gradient(135deg, #4F46E5, #9333EA)" }}
        animate={{
          y: [0, 40, 0],
          x: [0, 20, 0],
          scale: [1, 1.15, 1],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 right-[15%] w-96 h-96 rounded-full blur-3xl opacity-20"
        style={{ background: "linear-gradient(135deg, #06B6D4, #4F46E5)" }}
        animate={{
          y: [0, -40, 0],
          x: [0, -20, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      <div className="max-w-7xl mx-auto px-4 md:px-8 text-center relative z-10">
        <motion.div
          className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-[#4F46E5]/10 to-[#9333EA]/10 rounded-full mb-6"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <Sparkles className="w-5 h-5 text-[#4F46E5]" />
          <span className="text-[#4F46E5] font-semibold">Our Services</span>
        </motion.div>

        <motion.h1
          className="text-5xl md:text-7xl lg:text-8xl font-black mb-6"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <span className="bg-gradient-to-r from-[#4F46E5] via-[#9333EA] to-[#06B6D4] bg-clip-text text-transparent">
            Complete Digital Solutions
          </span>
        </motion.h1>

        <motion.p
          className="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          From websites to apps, marketing to branding—everything your business
          needs to thrive in the digital world.
        </motion.p>

        {/* Decorative Elements */}
        <motion.div
          className="absolute top-10 right-10 w-16 h-16 border-4 border-[#4F46E5]/20 rounded-2xl"
          animate={{
            rotate: [0, 90, 180, 270, 360],
            scale: [1, 1.1, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "linear",
          }}
        />
        <motion.div
          className="absolute bottom-10 left-10 w-20 h-20 border-4 border-[#06B6D4]/20 rounded-full"
          animate={{
            rotate: [0, -90, -180, -270, -360],
            scale: [1, 1.15, 1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      </div>
    </section>
  );
}
