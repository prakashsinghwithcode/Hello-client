import { motion } from "motion/react";
import {
  Briefcase,
  Award,
  Users,
  TrendingUp,
  Shield,
  Globe,
  Building2,
  GraduationCap,
  Heart,
  Scale,
  Landmark,
  Building,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function CorporateDesignService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="Business & Corporate Designs"
        tagline="Professional Designs That Give Your Business a Corporate Look"
        description="From business cards to complete stationery - all corporate designs that strengthen your professional image."
        icon={Briefcase}
        gradient="from-[#9333EA] to-[#06B6D4]"
      />

      <ServiceOverview
        whatItIs="Our Business & Corporate Designs service creates business cards, letterheads, envelopes, folders, and complete corporate identity. Every design is professional, consistent, and brand-aligned to make your business credible and trustworthy."
        whoItsFor="Established businesses, startups, professionals, and consultants - anyone who wants to present a professional image to clients and partners. This service is especially important for B2B businesses."
        problemItSolves="Generic or unprofessional stationery creates a poor impression on clients. Corporate clients expect professional presentation. We create designs that make you look professional in meetings, proposals, and every touchpoint."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: Award,
            title: "Professional Image",
            description:
              "High-quality corporate designs make your business appear established and trustworthy",
          },
          {
            icon: Users,
            title: "Build Credibility",
            description:
              "Professional stationery increases confidence from clients and partners",
          },
          {
            icon: TrendingUp,
            title: "Better Business Deals",
            description:
              "Corporate presentations help you secure larger clients and better deals",
          },
          {
            icon: Shield,
            title: "Brand Consistency",
            description:
              "Consistent branding on every document increases brand recall and recognition",
          },
          {
            icon: Globe,
            title: "Universal Appeal",
            description:
              "Professional designs that work across all industries and markets",
          },
          {
            icon: Briefcase,
            title: "Ready for Growth",
            description:
              "Scalable designs that can adapt as your business grows",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Brand Understanding",
            description:
              "We understand your business, industry, and target clients. We analyze brand values and positioning.",
          },
          {
            number: 2,
            title: "Design Strategy",
            description:
              "We decide on design direction - colors, fonts, style. We determine what look works best for your industry.",
          },
          {
            number: 3,
            title: "Design Creation",
            description:
              "We create coordinated designs for business cards, letterheads, and envelopes that look professional together.",
          },
          {
            number: 4,
            title: "Review & Refine",
            description:
              "We review and refine designs, keeping print quality and practical usage in mind.",
          },
          {
            number: 5,
            title: "Print-Ready Files",
            description:
              "We deliver final designs in print-ready formats and provide print guidelines for best results.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "Adobe Illustrator", description: "Vector Design", logo: "AI" },
          { name: "Adobe InDesign", description: "Layout Design", logo: "ID" },
          { name: "CorelDRAW", description: "Print Design", logo: "CD" },
          { name: "Photoshop", description: "Image Editing", logo: "PS" },
          { name: "Figma", description: "Digital Design", logo: "F" },
          { name: "Acrobat Pro", description: "PDF Management", logo: "AP" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "Business Cards",
            description:
              "Premium business card designs - single/double sided, various finishes available",
          },
          {
            name: "Letterheads",
            description:
              "Professional letterhead designs for official communications and documentation",
          },
          {
            name: "Envelopes & Folders",
            description:
              "Branded envelopes and presentation folders that present documents professionally",
          },
          {
            name: "Corporate Identity Kit",
            description:
              "Complete stationery package - cards, letterheads, envelopes, folders and more",
          },
          {
            name: "Email Signatures",
            description:
              "Professional email signature designs with logo, contact details, and social links",
          },
          {
            name: "Document Templates",
            description:
              "Branded templates for proposals, quotations, invoices, and reports",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: Building2,
            businessType: "Corporate Companies",
            howItHelps:
              "Complete corporate identity reflects professionalism. Client presentations become more impactful.",
          },
          {
            icon: Scale,
            businessType: "Legal Firms",
            howItHelps:
              "Professional stationery establishes trust and authority. Official documents look impressive.",
          },
          {
            icon: Landmark,
            businessType: "Financial Services",
            howItHelps:
              "Premium designs increase credibility. Clients gain confidence in financial matters.",
          },
          {
            icon: Building,
            businessType: "Real Estate",
            howItHelps:
              "Luxury-feel designs for high-end property businesses. Attract premium clients.",
          },
          {
            icon: GraduationCap,
            businessType: "Consulting Services",
            howItHelps:
              "Expertise-reflecting designs for professional consultants. Impress corporate clients.",
          },
          {
            icon: Heart,
            businessType: "Healthcare/Medical",
            howItHelps:
              "Clean, trust-building designs that convey medical professionalism. Give patients confidence.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}