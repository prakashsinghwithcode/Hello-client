import { motion } from "motion/react";
import {
  Smartphone,
  Zap,
  Users,
  Bell,
  Lock,
  TrendingUp,
  Store,
  GraduationCap,
  Heart,
  Utensils,
  Car,
  ShoppingBag,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function AppDevelopmentService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="App Development"
        tagline="Build Powerful Mobile Apps for Your Business"
        description="iOS and Android apps that deliver delightful customer experiences and take your business to new heights."
        icon={Smartphone}
        gradient="from-[#06B6D4] to-[#4F46E5]"
      />

      <ServiceOverview
        whatItIs="Our App Development services create mobile applications for both iOS (iPhone) and Android platforms. Whether native or cross-platform - we develop apps that are fast, smooth, and feature-rich."
        whoItsFor="Businesses that want to provide better mobile experiences to their customers. E-commerce stores, service providers, startups - anyone who wants to put their business in their customers' pockets."
        problemItSolves="Today, 90% of people spend their time on mobile devices. A website alone isn't enough - apps drive higher customer engagement, increase repeat business, and build brand loyalty. Push notifications enable direct customer communication."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: Users,
            title: "Better Customer Engagement",
            description:
              "Customers spend more time on apps and interact with your business on a regular basis",
          },
          {
            icon: Bell,
            title: "Direct Communication",
            description:
              "Send instant updates, offers, and reminders directly to customers via push notifications",
          },
          {
            icon: TrendingUp,
            title: "Increase Sales",
            description:
              "Easy checkout and saved preferences can boost conversion rates by up to 3x",
          },
          {
            icon: Zap,
            title: "Faster Experience",
            description:
              "Apps are faster than websites and some features work even offline",
          },
          {
            icon: Lock,
            title: "Secure & Reliable",
            description:
              "Bank-level security and reliable performance that builds customer trust",
          },
          {
            icon: Store,
            title: "Brand Visibility",
            description:
              "App Store and Play Store listings increase brand visibility and credibility",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Concept & Planning",
            description:
              "We plan every detail - app concept, features, and target users. We also conduct competitor analysis and market research.",
          },
          {
            number: 2,
            title: "UI/UX Design",
            description:
              "We create user-friendly and attractive app designs. Every screen flows smoothly and intuitively.",
          },
          {
            number: 3,
            title: "Development",
            description:
              "We develop apps using the latest technologies and optimize for both iOS and Android platforms.",
          },
          {
            number: 4,
            title: "Testing & QA",
            description:
              "We thoroughly test every feature, check performance across different devices, and fix any bugs.",
          },
          {
            number: 5,
            title: "Launch & Maintenance",
            description:
              "We publish your app on the App Store and Play Store, then provide continuous support for regular updates and maintenance.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "React Native", description: "Cross-platform", logo: "RN" },
          { name: "Flutter", description: "Google's Framework", logo: "F" },
          { name: "Swift", description: "iOS Development", logo: "S" },
          { name: "Kotlin", description: "Android Development", logo: "K" },
          { name: "Firebase", description: "Backend Services", logo: "FB" },
          { name: "AWS", description: "Cloud Infrastructure", logo: "A" },
          { name: "Figma", description: "UI/UX Design", logo: "FG" },
          { name: "TestFlight", description: "Beta Testing", logo: "T" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "iOS App Development",
            description:
              "Native iPhone apps with Apple's latest technologies - smooth performance and premium feel",
          },
          {
            name: "Android App Development",
            description:
              "Native Android apps that run perfectly on every device - from phones to tablets",
          },
          {
            name: "Cross-Platform Apps",
            description:
              "One codebase for both iOS and Android platforms - cost-effective and fast development",
          },
          {
            name: "E-commerce Apps",
            description:
              "Shopping apps with cart, payments, order tracking, wishlists - complete shopping experience",
          },
          {
            name: "On-Demand Service Apps",
            description:
              "Uber-style service apps - real-time tracking, booking, payments and more",
          },
          {
            name: "Progressive Web Apps",
            description:
              "The best of web and apps - access via browser, install on home screen",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: ShoppingBag,
            businessType: "E-commerce Store",
            howItHelps:
              "Dedicated shopping app lets customers browse easily, save carts, and order with one click. Announce offers via push notifications.",
          },
          {
            icon: Utensils,
            businessType: "Food Delivery",
            howItHelps:
              "Own restaurant app - menu browsing, order placement, live tracking. Avoid high commissions from third-party apps.",
          },
          {
            icon: GraduationCap,
            businessType: "Education/Coaching",
            howItHelps:
              "Learning app with video courses, quizzes, and progress tracking. Students can access complete courses from their mobile.",
          },
          {
            icon: Heart,
            businessType: "Healthcare/Fitness",
            howItHelps:
              "Appointment booking, health records, workout tracking. Users can manage their health journey from mobile.",
          },
          {
            icon: Car,
            businessType: "Transport/Logistics",
            howItHelps:
              "Booking app with real-time tracking, driver assignment, and automated billing. Complete digital transport management.",
          },
          {
            icon: Store,
            businessType: "Salon/Spa Services",
            howItHelps:
              "Service booking app - slot selection, stylist preference, payment integration. Convenient for customers and reduces no-shows.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}