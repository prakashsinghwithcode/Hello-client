import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useQuote } from "@/contexts/QuoteContext";
import {
  TrendingUp,
  Globe,
  Smartphone,
  Palette,
  Briefcase,
  BookOpen,
  FileText,
  Award,
  ArrowRight,
} from "lucide-react";

const services = [
  {
    id: 1,
    title: "Marketing Core Services",
    description: "SEO, Social Media, Content Marketing, PPC, Email Campaigns",
    icon: TrendingUp,
    gradient: "from-[#4F46E5] to-[#9333EA]",
    bgGradient: "from-blue-500/5 to-purple-500/5",
    link: "/services/marketing",
  },
  {
    id: 2,
    title: "Website Development Services",
    description: "Custom Websites, E-commerce, CMS, Landing Pages, Web Apps",
    icon: Globe,
    gradient: "from-[#9333EA] to-[#06B6D4]",
    bgGradient: "from-purple-500/5 to-cyan-500/5",
    link: "/services/web-development",
  },
  {
    id: 3,
    title: "App Development Services",
    description: "iOS Apps, Android Apps, Cross-Platform, Progressive Web Apps",
    icon: Smartphone,
    gradient: "from-[#06B6D4] to-[#4F46E5]",
    bgGradient: "from-cyan-500/5 to-blue-500/5",
    link: "/services/app-development",
  },
  {
    id: 4,
    title: "Marketing Design",
    description: "Social Media Graphics, Ad Banners, Infographics, Presentations",
    icon: Palette,
    gradient: "from-[#4F46E5] to-[#9333EA]",
    bgGradient: "from-blue-500/5 to-purple-500/5",
    link: "/services/marketing-design",
  },
  {
    id: 5,
    title: "Business & Corporate Designs",
    description: "Business Cards, Letterheads, Corporate Identity, Stationery",
    icon: Briefcase,
    gradient: "from-[#9333EA] to-[#06B6D4]",
    bgGradient: "from-purple-500/5 to-cyan-500/5",
    link: "/services/corporate-design",
  },
  {
    id: 6,
    title: "Catalogue & Book Designs",
    description: "Product Catalogs, Brochures, Magazines, E-books, Lookbooks",
    icon: BookOpen,
    gradient: "from-[#06B6D4] to-[#4F46E5]",
    bgGradient: "from-cyan-500/5 to-blue-500/5",
    link: "/services/catalogue-design",
  },
  {
    id: 7,
    title: "Digital Templates",
    description: "Email Templates, Social Templates, Presentation Decks, Documents",
    icon: FileText,
    gradient: "from-[#4F46E5] to-[#9333EA]",
    bgGradient: "from-blue-500/5 to-purple-500/5",
    link: "/services/digital-templates",
  },
  {
    id: 8,
    title: "Branding Kit",
    description: "Logo Design, Brand Guidelines, Color Palette, Typography System",
    icon: Award,
    gradient: "from-[#9333EA] to-[#06B6D4]",
    bgGradient: "from-purple-500/5 to-cyan-500/5",
    link: "/services/branding",
  },
];

export function ServicesGrid() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });
  const navigate = useNavigate();
  const { setQuoteMode } = useQuote();

  return (
    <section className="py-24 relative overflow-hidden" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-4xl md:text-5xl font-black mb-4 text-gray-900">
            Explore Our Services
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Choose a service to learn more about what we can do for your business
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;

            return (
              <motion.div
                key={service.id}
                initial={{
                  opacity: 0,
                  x: index % 2 === 0 ? -100 : 100,
                  y: 50,
                  filter: "blur(10px)",
                }}
                animate={
                  isInView
                    ? {
                        opacity: 1,
                        x: 0,
                        y: 0,
                        filter: "blur(0px)",
                      }
                    : {}
                }
                transition={{
                  duration: 0.8,
                  delay: index * 0.1,
                  ease: [0.25, 0.1, 0.25, 1],
                }}
                whileHover={{
                  scale: 1.02,
                  y: -5,
                }}
                className="group cursor-pointer"
              >
                <div className="relative h-full overflow-hidden rounded-3xl">
                  {/* Background with Gradient Shift on Hover */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${service.bgGradient} transition-all duration-500 group-hover:scale-110`}
                  />

                  {/* Border Glow Effect */}
                  <div className="absolute inset-0 rounded-3xl border-2 border-transparent group-hover:border-gray-200 transition-all duration-300" />

                  {/* Card Content */}
                  <div className="relative p-8 md:p-10">
                    {/* Icon with 3D Transform */}
                    <motion.div
                      className={`w-20 h-20 bg-gradient-to-r ${service.gradient} rounded-2xl flex items-center justify-center mb-6 shadow-lg`}
                      whileHover={{
                        rotateY: 180,
                        scale: 1.1,
                      }}
                      transition={{
                        duration: 0.6,
                        ease: "easeInOut",
                      }}
                      style={{
                        transformStyle: "preserve-3d",
                      }}
                    >
                      <Icon className="w-10 h-10 text-white" />
                    </motion.div>

                    {/* Title */}
                    <h3 className="text-2xl md:text-3xl font-bold mb-3 text-gray-900 group-hover:text-[#4F46E5] transition-colors duration-300">
                      {service.title}
                    </h3>

                    {/* Description */}
                    <p className="text-gray-600 leading-relaxed mb-6">
                      {service.description}
                    </p>

                    {/* Explore Button */}
                    <Link to={service.link}>
                      <motion.div
                        className="inline-flex items-center gap-2 text-[#4F46E5] font-semibold group-hover:gap-4 transition-all duration-300"
                        whileHover={{ x: 5 }}
                      >
                        <span>Explore Service</span>
                        <ArrowRight className="w-5 h-5" />
                      </motion.div>
                    </Link>

                    {/* Decorative Corner Element */}
                    <div
                      className={`absolute top-6 right-6 w-24 h-24 bg-gradient-to-r ${service.gradient} rounded-full blur-2xl opacity-10 transition-opacity duration-500 group-hover:opacity-20`}
                    />

                    {/* Animated Border on Hover */}
                    <motion.div
                      className={`absolute bottom-0 left-0 h-1 bg-gradient-to-r ${service.gradient} rounded-full`}
                      initial={{ width: "0%" }}
                      whileHover={{ width: "100%" }}
                      transition={{ duration: 0.4 }}
                    />
                  </div>

                  {/* Shine Effect on Hover */}
                  <div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-0 group-hover:opacity-10 transition-opacity duration-600 pointer-events-none"
                    style={{
                      transform: "translateX(-100%)",
                      transition: "transform 0.6s ease, opacity 0.6s ease",
                    }}
                  />
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          className="text-center mt-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 1 }}
        >
          <p className="text-lg text-gray-600 mb-6">
            Can't find what you're looking for?
          </p>
          <motion.button
            className="px-8 py-4 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] text-white font-bold rounded-full shadow-xl"
            whileHover={{
              scale: 1.05,
              boxShadow: "0 25px 50px rgba(79, 70, 229, 0.3)",
            }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setQuoteMode(true, "other");
              navigate("/contact");
            }}
          >
            Get Custom Quote
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}