import { motion } from "motion/react";
import {
  TrendingUp,
  Target,
  Users,
  DollarSign,
  BarChart3,
  Globe,
  Store,
  GraduationCap,
  UtensilsCrossed,
  Rocket,
  Building2,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";
import { PageTransition } from "../PageTransition";

export function MarketingService() {
  return (
    <PageTransition>
      <motion.div
        className="relative bg-white overflow-x-hidden"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <ScrollProgress />

        <ServiceHero
          title="Marketing Core Services"
          tagline="Transform Your Business Into an Online Success Story"
          description="From SEO to social media marketing - comprehensive digital marketing solutions that attract customers and drive sales growth."
          icon={TrendingUp}
          gradient="from-[#4F46E5] to-[#9333EA]"
        />

        <ServiceOverview
          whatItIs="Our Marketing Core Services encompass SEO, Social Media Marketing, Content Creation, PPC Advertising, and Email Campaigns. These integrated solutions help your business get discovered online, reach more customers, and increase sales."
          whoItsFor="This service is ideal for all types of businesses - whether you run a physical store, operate an e-commerce platform, or provide professional services. If you need to attract customers online, this is the perfect solution for you."
          problemItSolves="Many businesses have great products but struggle to find customers. Our Marketing Core Services solve this by getting your business to the top of Google, building a strong social media presence, and ensuring your message reaches the right audience."
        />

        <BusinessBenefits
          benefits={[
            {
              icon: Target,
              title: "Increase Sales",
              description:
                "Reach the right customers with targeted marketing and grow your sales by up to 3x",
            },
            {
              icon: Users,
              title: "Reach More Customers",
              description:
                "Expand your reach to hundreds of thousands of potential customers through social media and search engines",
            },
            {
              icon: BarChart3,
              title: "Better Online Presence",
              description:
                "Achieve #1 rankings on Google and outperform your competitors",
            },
            {
              icon: DollarSign,
              title: "Higher ROI",
              description:
                "Get 5-10x return on every dollar invested in marketing",
            },
            {
              icon: Globe,
              title: "Build Brand Trust",
              description:
                "Strengthen customer trust and brand value through consistent online presence",
            },
            {
              icon: TrendingUp,
              title: "Long-term Growth",
              description:
                "Sustainable marketing strategies that drive continuous business growth",
            },
          ]}
        />

        <OurApproach
          steps={[
            {
              number: 1,
              title: "Business Analysis",
              description:
                "We start by deeply understanding your business, competitors, and target audience. We research your unique selling points, identify your ideal customers, and analyze market opportunities.",
            },
            {
              number: 2,
              title: "Strategy Planning",
              description:
                "We create a custom marketing strategy aligned with your business goals. We determine the perfect mix of SEO, social media, content marketing, and paid advertising.",
            },
            {
              number: 3,
              title: "Campaign Execution",
              description:
                "Once the strategy is ready, we launch campaigns - running Google Ads, creating social media content, and optimizing your SEO to drive results.",
            },
            {
              number: 4,
              title: "Monitor & Optimize",
              description:
                "We continuously track results and optimize performance. By analyzing what works and what doesn't, we make data-driven improvements for better outcomes.",
            },
            {
              number: 5,
              title: "Report & Scale",
              description:
                "We provide detailed monthly reports showing your progress. Successful campaigns are scaled up for even better results and ROI.",
            },
          ]}
        />

        <ToolsTech
          tools={[
            { name: "Google Ads", description: "PPC Campaigns", logo: "G" },
            { name: "Meta Ads", description: "Facebook & Instagram", logo: "M" },
            { name: "Google Analytics", description: "Performance Tracking", logo: "GA" },
            { name: "SEMrush", description: "SEO Tools", logo: "S" },
            { name: "Mailchimp", description: "Email Marketing", logo: "MC" },
            { name: "Hootsuite", description: "Social Management", logo: "H" },
            { name: "Canva Pro", description: "Design Tools", logo: "C" },
            { name: "HubSpot", description: "Marketing Hub", logo: "HS" },
          ]}
        />

        <SubServicesGrid
          subServices={[
            {
              name: "SEO (Search Engine Optimization)",
              description:
                "Website optimization, keyword research, and link building to achieve top rankings on Google",
            },
            {
              name: "Social Media Marketing",
              description:
                "Engaging posts, reels, stories, and paid campaigns on Facebook, Instagram, and LinkedIn",
            },
            {
              name: "Content Marketing",
              description:
                "Blog posts, articles, and videos - valuable content that attracts and engages customers",
            },
            {
              name: "PPC Advertising",
              description:
                "Targeted campaigns through Google Ads and Facebook Ads for instant results",
            },
            {
              name: "Email Marketing",
              description:
                "Professional email campaigns for customer retention and driving repeat sales",
            },
            {
              name: "Influencer Marketing",
              description:
                "Strategic collaborations with the right influencers to boost brand awareness and reach",
            },
          ]}
        />

        <UseCases
          useCases={[
            {
              icon: Store,
              businessType: "Local Shop/Store",
              howItHelps:
                "Local SEO helps customers in your area easily find you on Google. Share offers on social media to increase foot traffic and sales.",
            },
            {
              icon: GraduationCap,
              businessType: "Educational Institute",
              howItHelps:
                "Boost new admissions with Facebook and Google Ads. Build trust and establish expertise through content marketing.",
            },
            {
              icon: UtensilsCrossed,
              businessType: "Restaurant/Cafe",
              howItHelps:
                "Attract customers by sharing appealing food photos on Instagram. Optimize Google My Business to appear in local searches.",
            },
            {
              icon: Rocket,
              businessType: "Startup/SaaS",
              howItHelps:
                "Build thought leadership through content marketing. Acquire customers quickly and scale with PPC advertising.",
            },
            {
              icon: Building2,
              businessType: "B2B Services",
              howItHelps:
                "Reach decision-makers through LinkedIn marketing. Generate consistent leads with SEO without needing a sales team.",
            },
            {
              icon: Globe,
              businessType: "E-commerce Store",
              howItHelps:
                "Increase product visibility with Google Shopping Ads. Recover abandoned carts using social media remarketing.",
            },
          ]}
        />

        <ServiceCTA />
        <Footer />
        <StickyConsultationButton />
      </motion.div>
    </PageTransition>
  );
}