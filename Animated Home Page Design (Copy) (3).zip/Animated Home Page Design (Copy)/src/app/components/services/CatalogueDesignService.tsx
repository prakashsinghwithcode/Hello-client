import { motion } from "motion/react";
import {
  BookOpen,
  Eye,
  TrendingUp,
  Package,
  Award,
  Zap,
  Store,
  Building2,
  Briefcase,
  Heart,
  GraduationCap,
  Home,
} from "lucide-react";
import { ServiceHero } from "../service-detail/ServiceHero";
import { ServiceOverview } from "../service-detail/ServiceOverview";
import { BusinessBenefits } from "../service-detail/BusinessBenefits";
import { OurApproach } from "../service-detail/OurApproach";
import { ToolsTech } from "../service-detail/ToolsTech";
import { SubServicesGrid } from "../service-detail/SubServicesGrid";
import { UseCases } from "../service-detail/UseCases";
import { ServiceCTA } from "../service-detail/ServiceCTA";
import { ScrollProgress } from "../service-detail/ScrollProgress";
import { Footer } from "../Footer";
import { StickyConsultationButton } from "../StickyConsultationButton";

export function CatalogueDesignService() {
  return (
    <motion.div
      className="relative bg-white overflow-x-hidden"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <ScrollProgress />

      <ServiceHero
        title="Catalogue & Book Designs"
        tagline="Beautiful Catalogues That Make Your Products Shine"
        description="From product catalogues to magazines - all print materials professionally designed and visually stunning."
        icon={BookOpen}
        gradient="from-[#06B6D4] to-[#4F46E5]"
      />

      <ServiceOverview
        whatItIs="Our Catalogue & Book Designs service creates product catalogues, brochures, magazines, e-books, lookbooks, and annual reports. Every page is professionally laid out, visually attractive, and information-rich to engage readers."
        whoItsFor="Manufacturing companies, retail businesses, fashion brands, and educational publishers - anyone who wants to beautifully present their products, services, or content in print or digital format."
        problemItSolves="Boring catalogues that no one wants to read. Product information isn't clear or designs look unprofessional. We create catalogues that attract customers, highlight products, and generate sales."
      />

      <BusinessBenefits
        benefits={[
          {
            icon: Eye,
            title: "Visual Appeal",
            description:
              "Stunning layouts and professional photography make catalogues visually captivating",
          },
          {
            icon: TrendingUp,
            title: "Increase Sales",
            description:
              "Well-designed catalogues can increase product interest and sales inquiries by 3x",
          },
          {
            icon: Package,
            title: "Better Product Showcase",
            description:
              "Present every product in the best possible way with proper descriptions and specifications",
          },
          {
            icon: Award,
            title: "Professional Image",
            description:
              "High-quality catalogues make your brand appear premium and established",
          },
          {
            icon: Zap,
            title: "Easy Information",
            description:
              "Well-organized layouts help customers find the information they need easily",
          },
          {
            icon: BookOpen,
            title: "Lasting Impression",
            description:
              "Quality catalogues are kept and referred to by customers - a long-term marketing tool",
          },
        ]}
      />

      <OurApproach
        steps={[
          {
            number: 1,
            title: "Content Planning",
            description:
              "We plan products, sections, and page count. We create information architecture for logical flow.",
          },
          {
            number: 2,
            title: "Layout Design",
            description:
              "We create page templates and decide layouts for cover design, inner pages, and section dividers.",
          },
          {
            number: 3,
            title: "Content Integration",
            description:
              "We beautifully integrate product images, descriptions, and specifications while maintaining visual hierarchy.",
          },
          {
            number: 4,
            title: "Review & Refinement",
            description:
              "We review the complete catalogue, checking typos, alignment, and image quality, then refine everything.",
          },
          {
            number: 5,
            title: "Final Delivery",
            description:
              "We deliver print-ready PDFs and digital versions along with print specifications.",
          },
        ]}
      />

      <ToolsTech
        tools={[
          { name: "Adobe InDesign", description: "Layout Design", logo: "ID" },
          { name: "Photoshop", description: "Image Editing", logo: "PS" },
          { name: "Illustrator", description: "Vector Graphics", logo: "AI" },
          { name: "Lightroom", description: "Photo Enhancement", logo: "LR" },
          { name: "Acrobat Pro", description: "PDF Creation", logo: "AP" },
          { name: "QuarkXPress", description: "Publishing", logo: "QX" },
        ]}
      />

      <SubServicesGrid
        subServices={[
          {
            name: "Product Catalogues",
            description:
              "Comprehensive product catalogs with images, descriptions, pricing, and specifications",
          },
          {
            name: "Marketing Brochures",
            description:
              "Bi-fold, tri-fold brochures for company/product promotion with engaging content",
          },
          {
            name: "Magazines & Newsletters",
            description:
              "Periodic publications with editorial layouts, articles, and advertisements",
          },
          {
            name: "E-books & Digital Books",
            description:
              "Digital publications optimized for tablets, e-readers, and online viewing",
          },
          {
            name: "Lookbooks & Portfolios",
            description:
              "Fashion lookbooks, photographer portfolios - visual showcase documents",
          },
          {
            name: "Annual Reports",
            description:
              "Corporate annual reports with data visualizations, financial charts, and narratives",
          },
        ]}
      />

      <UseCases
        useCases={[
          {
            icon: Store,
            businessType: "Retail/Wholesale",
            howItHelps:
              "Show dealers and customers your complete product range. Easy comparison of prices and specifications.",
          },
          {
            icon: Building2,
            businessType: "Manufacturing",
            howItHelps:
              "Showcase product capabilities with technical catalogues. Provide detailed information to B2B clients.",
          },
          {
            icon: Briefcase,
            businessType: "Fashion/Apparel",
            howItHelps:
              "Present seasonal collections with lookbooks. Provide attractive presentations to retailers and buyers.",
          },
          {
            icon: Home,
            businessType: "Interior/Furniture",
            howItHelps:
              "Showcase designs and options with product catalogues. Help customers visualize products in their space.",
          },
          {
            icon: GraduationCap,
            businessType: "Educational Publishers",
            howItHelps:
              "Course books, study materials, guides - professionally designed educational content that's engaging.",
          },
          {
            icon: Heart,
            businessType: "Healthcare/Medical",
            howItHelps:
              "Medical equipment catalogues, pharmaceutical product brochures - technical yet accessible designs.",
          },
        ]}
      />

      <ServiceCTA />
      <Footer />
      <StickyConsultationButton />
    </motion.div>
  );
}