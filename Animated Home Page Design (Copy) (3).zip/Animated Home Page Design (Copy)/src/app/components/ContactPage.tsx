import { useEffect } from "react";
import { useQuote } from "@/contexts/QuoteContext";
import { ContactHero } from "./contact/ContactHero";
import { ContactForm } from "./contact/ContactForm";
import { ContactInfo } from "./contact/ContactInfo";
import { LocationSection } from "./contact/LocationSection";
import { WhyContactUs } from "./contact/WhyContactUs";
import { ContactCTA } from "./contact/ContactCTA";
import { Footer } from "./Footer";
import { StickyConsultationButton } from "./StickyConsultationButton";
import { SmoothScroll } from "./SmoothScroll";
import { PageTransition } from "./PageTransition";

export function ContactPage() {
  const { resetQuoteMode } = useQuote();

  // Reset quote mode when leaving the page
  useEffect(() => {
    return () => {
      resetQuoteMode();
    };
  }, [resetQuoteMode]);

  return (
    <PageTransition>
      <SmoothScroll>
        <div className="relative overflow-x-hidden bg-white">
          {/* Contact Hero Section */}
          <ContactHero />

          {/* Main Contact Form + Contact Info */}
          <section className="relative py-20 bg-gradient-to-b from-white via-blue-50/30 to-white">
            <div className="max-w-7xl mx-auto px-4 md:px-8">
              <div className="grid lg:grid-cols-3 gap-12">
                {/* Main Form - 2 columns */}
                <div className="lg:col-span-2">
                  <ContactForm />
                </div>

                {/* Contact Info - 1 column */}
                <div className="lg:col-span-1">
                  <ContactInfo />
                </div>
              </div>
            </div>
          </section>

          {/* Map/Location Section */}
          <LocationSection />

          {/* Why Contact Us */}
          <WhyContactUs />

          {/* Final CTA Strip */}
          <ContactCTA />

          {/* Footer */}
          <Footer />

          {/* Sticky Consultation Button */}
          <StickyConsultationButton />
        </div>
      </SmoothScroll>
    </PageTransition>
  );
}