import { Link } from "react-router-dom";

interface LogoProps {
  variant?: "default" | "dark";
  iconOnly?: boolean;
}

interface LogoIconProps {
  size?: number;
  variant?: "default" | "dark";
}

interface LogoMonochromeProps {
  variant?: "dark" | "light";
}

// Core logo mark - Sharp geometric "H" with tech-forward design
function LogoMark({ size = 40, color = "#3730A3", className = "" }: { size?: number; color?: string; className?: string }) {
  const scale = size / 40; // Base design at 40x40
  
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 40 40" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Left vertical bar */}
      <rect 
        x="7" 
        y="8" 
        width="6" 
        height="24" 
        rx="1.5"
        fill={color}
      />
      
      {/* Right vertical bar */}
      <rect 
        x="27" 
        y="8" 
        width="6" 
        height="24" 
        rx="1.5"
        fill={color}
      />
      
      {/* Horizontal bridge - the connecting element */}
      <rect 
        x="13" 
        y="17" 
        width="14" 
        height="6" 
        rx="1.5"
        fill={color}
      />
      
      {/* Subtle depth accent - top right corner */}
      <circle 
        cx="30" 
        cy="11" 
        r="1.5" 
        fill="#06B6D4"
        opacity="0.4"
      />
      
      {/* Connection node - center */}
      <circle 
        cx="20" 
        cy="20" 
        r="2" 
        fill={color}
      />
    </svg>
  );
}

// Main Logo Component - Horizontal with text
export function Logo({ variant = "default", iconOnly = false }: LogoProps) {
  const isDark = variant === "dark";
  const iconColor = isDark ? "#FFFFFF" : "#3730A3"; // Deep Indigo
  const textColor = isDark ? "text-white" : "text-gray-900";
  const domainColor = isDark ? "text-gray-300" : "text-gray-500";
  
  return (
    <Link to="/" className="flex items-center gap-3 group cursor-pointer">
      {/* Logo Icon with hover glow */}
      <div className="relative">
        <LogoMark 
          size={40} 
          color={iconColor}
          className="transition-transform duration-300 group-hover:scale-105"
        />
        
        {/* Glow effect on hover - only for default variant */}
        {!isDark && (
          <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300 -z-10" />
        )}
      </div>
      
      {/* Logo Text */}
      {!iconOnly && (
        <div className="flex items-baseline gap-0">
          <span className={`text-[22px] font-bold tracking-[0.02em] ${textColor} transition-colors`}>
            Hello Client
          </span>
          <span className={`text-[22px] font-semibold tracking-wide ${domainColor} transition-colors`}>
            .in
          </span>
        </div>
      )}
    </Link>
  );
}

// Icon-only variant for smaller spaces (favicon, app icon, mobile)
export function LogoIcon({ size = 40, variant = "default" }: LogoIconProps) {
  const color = variant === "dark" ? "#FFFFFF" : "#3730A3";
  
  return (
    <div className="relative group cursor-pointer" style={{ width: size, height: size }}>
      <LogoMark 
        size={size} 
        color={color}
        className="transition-transform duration-300 group-hover:scale-105"
      />
    </div>
  );
}

// Monochrome version for special use cases (prints, watermarks)
export function LogoMonochrome({ variant = "dark" }: LogoMonochromeProps) {
  const fillColor = variant === "dark" ? "#111827" : "#FFFFFF";
  
  return (
    <Link to="/" className="flex items-center gap-3 group cursor-pointer">
      <LogoMark 
        size={40} 
        color={fillColor}
        className="transition-transform duration-300 group-hover:scale-105"
      />
      
      <div className="flex items-baseline gap-0">
        <span 
          className="text-[22px] font-bold tracking-[0.02em] transition-colors"
          style={{ color: fillColor }}
        >
          Hello Client
        </span>
        <span 
          className="text-[22px] font-semibold tracking-wide opacity-70 transition-colors"
          style={{ color: fillColor }}
        >
          .in
        </span>
      </div>
    </Link>
  );
}

// Square version with background - for app icons, social media
export function LogoSquare({ size = 512, background = "gradient" }: { size?: number; background?: "gradient" | "solid" | "transparent" }) {
  let bgStyle = {};
  
  if (background === "gradient") {
    bgStyle = {
      background: "linear-gradient(135deg, #3730A3 0%, #4F46E5 50%, #06B6D4 100%)"
    };
  } else if (background === "solid") {
    bgStyle = {
      background: "#3730A3"
    };
  }
  
  const iconSize = size * 0.55; // Icon takes 55% of square
  const padding = (size - iconSize) / 2;
  
  return (
    <div 
      className="relative flex items-center justify-center rounded-2xl"
      style={{ 
        width: size, 
        height: size,
        ...bgStyle
      }}
    >
      <LogoMark 
        size={iconSize} 
        color="#FFFFFF"
      />
    </div>
  );
}

// Dark background variant - for dark mode UIs
export function LogoDark({ iconOnly = false }: { iconOnly?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-3 group cursor-pointer">
      <div className="relative">
        <LogoMark 
          size={40} 
          color="#FFFFFF"
          className="transition-transform duration-300 group-hover:scale-105"
        />
        
        {/* Cyan glow on dark backgrounds */}
        <div className="absolute inset-0 rounded-lg bg-cyan-400 opacity-0 group-hover:opacity-30 blur-xl transition-opacity duration-300 -z-10" />
      </div>
      
      {!iconOnly && (
        <div className="flex items-baseline gap-0">
          <span className="text-[22px] font-bold tracking-[0.02em] text-white transition-colors">
            Hello Client
          </span>
          <span className="text-[22px] font-semibold tracking-wide text-gray-300 transition-colors">
            .in
          </span>
        </div>
      )}
    </Link>
  );
}