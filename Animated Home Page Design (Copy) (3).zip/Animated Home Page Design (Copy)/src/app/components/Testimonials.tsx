import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Rohit Sharma",
    role: "CEO",
    company: "Tech Solutions Mumbai",
    rating: 5,
    text: "Hello Client.in completely transformed our digital presence. Revenue increased by 150% in just 6 months. The team is professional, creative, and delivers beyond expectations.",
    image: "RS",
    gradient: "from-blue-500 to-cyan-500",
  },
  {
    id: 2,
    name: "Priya Patel",
    role: "Founder",
    company: "Fashion Hub Ahmedabad",
    rating: 5,
    text: "Outstanding work! They created a beautiful e-commerce platform for my fashion business. Sales have tripled and customer feedback is amazing. Best digital agency in India!",
    image: "PP",
    gradient: "from-purple-500 to-pink-500",
  },
  {
    id: 3,
    name: "Ankit Verma",
    role: "Marketing Head",
    company: "EduTech Delhi",
    rating: 5,
    text: "Their digital marketing strategies are phenomenal. Social media engagement up 300%, leads increased significantly. The team understands our business and delivers results.",
    image: "AV",
    gradient: "from-green-500 to-teal-500",
  },
  {
    id: 4,
    name: "Neha Agarwal",
    role: "Owner",
    company: "Wellness Clinic Bangalore",
    rating: 5,
    text: "Beautiful branding and website design! Patient inquiries doubled within weeks. Professional team, great communication, delivered exactly what we needed.",
    image: "NA",
    gradient: "from-orange-500 to-red-500",
  },
  {
    id: 5,
    name: "Aman Singh",
    role: "Director",
    company: "Real Estate Pune",
    rating: 5,
    text: "They built our property platform with all features we needed. The app is fast, user-friendly, and our clients love it. Highly recommended for real estate businesses!",
    image: "AS",
    gradient: "from-indigo-500 to-purple-500",
  },
  {
    id: 6,
    name: "Pooja Reddy",
    role: "Co-Founder",
    company: "Food Delivery Hyderabad",
    rating: 5,
    text: "Exceptional work on our food delivery platform. The app performs flawlessly and their ongoing support is outstanding. Best decision we made for our startup!",
    image: "PR",
    gradient: "from-pink-500 to-rose-500",
  },
];

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const testimonial = testimonials[currentIndex];

  return (
    <section className="py-32 px-4 md:px-8 bg-gray-50 relative overflow-hidden">
      {/* Background */}
      <motion.div
        className="absolute top-0 left-0 w-96 h-96 rounded-full blur-3xl"
        style={{
          background: 'linear-gradient(to bottom right, rgb(191, 219, 254), rgb(221, 214, 254))',
          opacity: 0.2,
        }}
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{ duration: 15, repeat: Infinity }}
      />
      <motion.div
        className="absolute bottom-0 right-0 w-96 h-96 rounded-full blur-3xl"
        style={{
          background: 'linear-gradient(to bottom right, rgb(165, 243, 252), rgb(191, 219, 254))',
          opacity: 0.2,
        }}
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{ duration: 15, repeat: Infinity, delay: 2 }}
      />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full"
          >
            Client Success Stories
          </motion.div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black text-gray-900 mb-6">
            Trusted by
            <br />
            <span className="bg-gradient-to-r from-[#4F46E5] via-[#9333EA] to-[#06B6D4] bg-clip-text text-transparent">
              India's Best
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Real results from real businesses across India
          </p>
        </motion.div>

        {/* Testimonial Card */}
        <div className="relative">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
            className="relative"
          >
            <div className="relative bg-white rounded-3xl p-8 md:p-12 lg:p-16 shadow-2xl overflow-hidden">
              {/* Quote Icon */}
              <motion.div
                className="absolute top-8 right-8 opacity-5"
                animate={{ rotate: [0, 10, 0] }}
                transition={{ duration: 5, repeat: Infinity }}
              >
                <Quote className="w-32 h-32 text-gray-900" />
              </motion.div>

              {/* Content */}
              <div className="relative z-10">
                {/* Stars */}
                <motion.div
                  className="flex gap-1 mb-6"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0, rotate: -180 }}
                      animate={{ opacity: 1, scale: 1, rotate: 0 }}
                      transition={{ delay: 0.3 + i * 0.1, type: "spring" }}
                    >
                      <Star className="w-6 h-6 fill-yellow-400 text-yellow-400" />
                    </motion.div>
                  ))}
                </motion.div>

                {/* Text */}
                <motion.p
                  className="text-xl md:text-2xl text-gray-700 leading-relaxed mb-8"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                >
                  "{testimonial.text}"
                </motion.p>

                {/* Author */}
                <motion.div
                  className="flex items-center gap-4"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                >
                  {/* Avatar */}
                  <motion.div
                    className={`w-16 h-16 rounded-full bg-gradient-to-br ${testimonial.gradient} flex items-center justify-center text-white text-xl font-bold shadow-lg`}
                    animate={{
                      boxShadow: [
                        "0 0 20px rgba(79, 70, 229, 0.3)",
                        "0 0 30px rgba(147, 51, 234, 0.4)",
                        "0 0 20px rgba(79, 70, 229, 0.3)",
                      ],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  >
                    {testimonial.image}
                  </motion.div>

                  {/* Info */}
                  <div>
                    <div className="font-bold text-xl text-gray-900">
                      {testimonial.name}
                    </div>
                    <div className="text-gray-600">
                      {testimonial.role}, {testimonial.company}
                    </div>
                  </div>
                </motion.div>
              </div>

              {/* Gradient Accent */}
              <motion.div
                className={`absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r ${testimonial.gradient}`}
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ delay: 0.6, duration: 0.8 }}
              />
            </div>
          </motion.div>

          {/* Navigation */}
          <button
            onClick={prevTestimonial}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-16 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center hover:scale-110 transition-transform"
          >
            <ChevronLeft className="w-6 h-6 text-gray-800" />
          </button>
          <button
            onClick={nextTestimonial}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-16 w-12 h-12 rounded-full bg-white shadow-xl flex items-center justify-center hover:scale-110 transition-transform"
          >
            <ChevronRight className="w-6 h-6 text-gray-800" />
          </button>
        </div>

        {/* Indicators */}
        <div className="flex justify-center gap-2 mt-12">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className="group"
            >
              <div
                className={`h-2 rounded-full transition-all duration-300 ${
                  index === currentIndex
                    ? "w-12 bg-gradient-to-r from-blue-500 to-purple-500"
                    : "w-8 bg-gray-300 hover:bg-gray-400"
                }`}
              />
            </button>
          ))}
        </div>

        {/* Trust Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-20"
        >
          {[
            { number: "500+", label: "Happy Clients" },
            { number: "98%", label: "Satisfaction" },
            { number: "5★", label: "Average Rating" },
            { number: "24/7", label: "Support" },
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, type: "spring" }}
              className="text-center"
            >
              <div className="text-4xl md:text-5xl font-black bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}