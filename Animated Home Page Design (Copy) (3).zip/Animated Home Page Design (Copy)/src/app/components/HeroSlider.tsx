import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Eye, Phone } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useConsultation } from "@/contexts/ConsultationContext";

const heroSlides = [
  {
    id: 1,
    mainText: "Hello Client.in",
    subText: "Digital Agency for Business Growth",
    tagline: "We Transform Ideas Into Digital Reality",
  },
  {
    id: 2,
    mainText: "Powerful Digital",
    subText: "Experiences",
    tagline: "Creating Brands That People Love",
  },
  {
    id: 3,
    mainText: "Complete Digital",
    subText: "Solutions",
    tagline: "Web • App • Marketing • Design",
  },
  {
    id: 4,
    mainText: "Grow Your Business",
    subText: "Online",
    tagline: "Data-Driven Growth Strategies",
  },
  {
    id: 5,
    mainText: "Start Your Journey",
    subText: "Today",
    tagline: "Let's Build Something Amazing Together",
  },
];

export function HeroSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();
  const { setConsultationOpen } = useConsultation();

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000); // 5 seconds - calm, premium timing for clear reading
    return () => clearInterval(timer);
  }, []);

  const slide = heroSlides[currentSlide];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-white pt-16 md:pt-0">
      {/* Animated Grid Background */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50" />
        <motion.div
          className="absolute inset-0 opacity-[0.03] hidden md:block"
          style={{
            backgroundImage: `linear-gradient(#4F46E5 1px, transparent 1px), linear-gradient(90deg, #4F46E5 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
          animate={{
            backgroundPosition: ["0px 0px", "50px 50px"],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear",
          }}
        />
      </div>

      {/* Floating Orbs - Reduced on mobile */}
      <motion.div
        className="absolute top-20 left-[10%] w-32 h-32 md:w-64 md:h-64 rounded-full blur-3xl opacity-20"
        style={{
          background: "linear-gradient(135deg, #4F46E5, #9333EA)",
        }}
        animate={{
          y: [0, 30, 0],
          x: [0, 20, 0],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 8,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-20 right-[10%] w-40 h-40 md:w-80 md:h-80 rounded-full blur-3xl opacity-20"
        style={{
          background: "linear-gradient(135deg, #06B6D4, #4F46E5)",
        }}
        animate={{
          y: [0, -30, 0],
          x: [0, -20, 0],
          scale: [1, 1.3, 1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 md:px-8 text-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ 
              duration: 1.2, 
              ease: [0.43, 0.13, 0.23, 0.96] // Cinematic cubic-bezier easing
            }}
          >
            {/* Main Text */}
            <motion.div
              className="mb-6"
              initial={{ y: 40, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
            >
              <h1 className="text-4xl sm:text-5xl md:text-7xl lg:text-8xl xl:text-9xl font-black tracking-tight mb-4 leading-tight">
                {slide.mainText.split(" ").map((word, index) => (
                  <motion.span
                    key={index}
                    className="inline-block"
                    initial={{ y: 60, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ 
                      duration: 0.8, 
                      delay: 0.3 + index * 0.15,
                      ease: [0.43, 0.13, 0.23, 0.96]
                    }}
                  >
                    <span
                      className="bg-gradient-to-r from-[#4F46E5] via-[#9333EA] to-[#06B6D4] bg-clip-text text-transparent"
                      style={{
                        display: "inline-block",
                      }}
                    >
                      {word}
                    </span>
                    {index < slide.mainText.split(" ").length - 1 && " "}
                  </motion.span>
                ))}
              </h1>
            </motion.div>

            {/* Sub Text */}
            <motion.h2
              className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-800 mb-6"
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.6, ease: "easeOut" }}
            >
              {slide.subText}
            </motion.h2>

            {/* Tagline */}
            <motion.p
              className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto px-4"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 0.8, ease: "easeOut" }}
            >
              {slide.tagline}
            </motion.p>
            </motion.div>
          </AnimatePresence>
            {/* CTA Buttons - Always Present */}
            <motion.div
              className="flex flex-col gap-4 justify-center items-center px-4"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 1, delay: 1, ease: "easeOut" }}
            >
              <motion.button
                className="w-full sm:w-auto px-8 sm:px-10 py-4 sm:py-5 bg-gradient-to-r from-[#4F46E5] to-[#9333EA] text-white text-base sm:text-lg font-bold rounded-full flex items-center justify-center gap-3 shadow-2xl relative overflow-hidden min-h-[56px]"
                whileHover={{ scale: 1.05, boxShadow: "0 25px 50px rgba(79, 70, 229, 0.4)" }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setConsultationOpen(true)}
              >
                {/* Pulse Animation */}
                <motion.div
                  className="absolute inset-0 bg-white/20 rounded-full"
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.5, 0, 0.5],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                  }}
                />
                <span className="relative z-10">Get Free Consultation</span>
                <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6 relative z-10" />
              </motion.button>
              
              <motion.button
                className="w-full sm:w-auto px-8 sm:px-10 py-4 sm:py-5 bg-white/80 backdrop-blur-sm text-gray-800 text-base sm:text-lg font-bold rounded-full flex items-center justify-center gap-3 border-2 border-gray-300 hover:border-[#4F46E5] shadow-lg min-h-[56px]"
                whileHover={{ scale: 1.05, borderColor: "#4F46E5" }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate("/services")}
              >
                <Eye className="w-5 h-5 sm:w-6 sm:h-6" />
                View Services
              </motion.button>
            </motion.div>
          
        
      </div>
    </section>
  );
}