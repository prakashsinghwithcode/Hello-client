import { useState } from "react";
import { motion } from "motion/react";
import { Link, useNavigate } from "react-router-dom";
import {
  SearchCheck,
  Globe,
  Tablet,
  Palette,
  Briefcase,
  BookOpen,
  Image,
  Award,
  Plus,
  X,
  ArrowRight,
} from "lucide-react";

const services = [
  {
    id: 1,
    title: "Marketing Core",
    icon: SearchCheck,
    gradient: "from-blue-500 to-cyan-500",
    description: "Drive traffic, leads, and conversions",
    items: [
      "SEO Optimization",
      "Google Ads Management",
      "Social Media Marketing",
      "Content Strategy",
      "Email Campaigns",
      "YouTube Marketing",
      "Lead Generation",
      "Online Reputation",
      "GMB Optimization",
    ],
  },
  {
    id: 2,
    title: "Website Development",
    icon: Globe,
    gradient: "from-purple-500 to-pink-500",
    description: "Beautiful, functional websites",
    items: [
      "Business Websites",
      "Portfolio Sites",
      "E-commerce Stores",
      "Blog Platforms",
      "Educational Sites",
      "Real Estate Portals",
      "Healthcare Sites",
      "School Websites",
      "Landing Pages",
    ],
  },
  {
    id: 3,
    title: "App Development",
    icon: Tablet,
    gradient: "from-green-500 to-teal-500",
    description: "Native and hybrid mobile apps",
    items: [
      "Android Apps",
      "iOS Applications",
      "Hybrid Solutions",
      "Business Apps",
      "E-commerce Apps",
      "Booking Systems",
      "Learning Platforms",
      "Delivery Apps",
      "Custom Solutions",
    ],
  },
  {
    id: 4,
    title: "Marketing Design",
    icon: Palette,
    gradient: "from-orange-500 to-red-500",
    description: "Eye-catching promotional materials",
    items: [
      "Poster Design",
      "Flex Banners",
      "Hoardings",
      "Flyers",
      "Brochures",
      "Standees",
      "Menu Cards",
      "Price Lists",
    ],
  },
  {
    id: 5,
    title: "Corporate Design",
    icon: Briefcase,
    gradient: "from-indigo-500 to-purple-500",
    description: "Professional business stationery",
    items: [
      "Visiting Cards",
      "Letterheads",
      "Envelopes",
      "Invoices",
      "Company Profiles",
      "Presentations",
      "Proposals",
      "ID Cards",
    ],
  },
  {
    id: 6,
    title: "Catalogue & Books",
    icon: BookOpen,
    gradient: "from-pink-500 to-rose-500",
    description: "Print-ready publications",
    items: [
      "Product Catalogues",
      "Service Catalogues",
      "PDF Documents",
      "Magazines",
      "Book Covers",
      "E-books",
      "Manuals",
      "Prospectus",
    ],
  },
  {
    id: 7,
    title: "Digital Templates",
    icon: Image,
    gradient: "from-yellow-500 to-orange-500",
    description: "Social media & digital assets",
    items: [
      "Social Posts",
      "Reels Covers",
      "Thumbnails",
      "Web Banners",
      "WhatsApp Graphics",
      "Email Templates",
      "Festival Posts",
      "Ad Creatives",
    ],
  },
  {
    id: 8,
    title: "Branding Kit",
    icon: Award,
    gradient: "from-cyan-500 to-blue-500",
    description: "Complete brand identity",
    items: [
      "Logo Design",
      "Color Palette",
      "Typography",
      "Brand Guidelines",
      "Social Media Kit",
      "Stationery Set",
      "Brand Assets",
    ],
  },
];

export function ServicesSection() {
  const [selectedService, setSelectedService] = useState<number | null>(null);
  const navigate = useNavigate();

  return (
    <section className="py-32 px-4 md:px-8 bg-gray-50 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-0 right-0 w-96 h-96 rounded-full blur-3xl"
          style={{
            background: 'linear-gradient(to bottom right, rgb(191, 219, 254), rgb(221, 214, 254))',
            opacity: 0.2,
          }}
          animate={{
            scale: [1, 1.2, 1],
            x: [0, 50, 0],
            y: [0, 30, 0],
          }}
          transition={{ duration: 15, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-0 left-0 w-96 h-96 rounded-full blur-3xl"
          style={{
            background: 'linear-gradient(to bottom right, rgb(165, 243, 252), rgb(191, 219, 254))',
            opacity: 0.2,
          }}
          animate={{
            scale: [1, 1.3, 1],
            x: [0, -50, 0],
            y: [0, -30, 0],
          }}
          transition={{ duration: 15, repeat: Infinity, delay: 2 }}
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full"
          >
            Our Services
          </motion.div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black text-gray-900 mb-6">
            Everything You Need
            <br />
            <span className="bg-gradient-to-r from-[#4F46E5] via-[#9333EA] to-[#06B6D4] bg-clip-text text-transparent">
              Under One Roof
            </span>
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Comprehensive digital solutions to transform your business and accelerate growth
          </p>
        </motion.div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            const isSelected = selectedService === service.id;

            return (
              <motion.div
                key={service.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group relative"
              >
                <motion.div
                  className="relative h-full bg-white rounded-3xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer overflow-hidden"
                  whileHover={{ y: -10 }}
                  onClick={() => setSelectedService(service.id)}
                >
                  {/* Gradient Overlay */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}
                  />

                  {/* Icon */}
                  <motion.div
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.gradient} flex items-center justify-center mb-6 relative z-10`}
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Title */}
                  <h3 className="text-2xl font-bold text-gray-900 mb-3 relative z-10">
                    {service.title}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-600 mb-4 relative z-10">
                    {service.description}
                  </p>

                  {/* Item Count Badge */}
                  <div className="flex items-center justify-between relative z-10">
                    <span className="text-sm text-gray-500">
                      {service.items.length} services
                    </span>
                    <motion.button
                      className={`w-8 h-8 rounded-full bg-gradient-to-br ${service.gradient} flex items-center justify-center text-white`}
                      whileHover={{ scale: 1.2, rotate: 90 }}
                      whileTap={{ scale: 0.9 }}
                    >
                      <Plus className="w-5 h-5" />
                    </motion.button>
                  </div>

                  {/* Hover Effect Line */}
                  <motion.div
                    className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${service.gradient}`}
                    initial={{ scaleX: 0 }}
                    whileHover={{ scaleX: 1 }}
                    transition={{ duration: 0.3 }}
                  />
                </motion.div>
              </motion.div>
            );
          })}
        </div>

        {/* View All Services Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="text-center mt-16"
        >
          <Link to="/services">
            <motion.button
              className="inline-flex items-center gap-3 px-10 py-5 bg-gradient-to-r from-[#4F46E5] via-[#9333EA] to-[#06B6D4] text-white font-bold text-lg rounded-full shadow-2xl"
              whileHover={{
                scale: 1.05,
                boxShadow: "0 25px 50px rgba(79, 70, 229, 0.4)",
              }}
              whileTap={{ scale: 0.95 }}
            >
              <span>View All Services</span>
              <ArrowRight className="w-6 h-6" />
            </motion.button>
          </Link>
        </motion.div>
      </div>

      {/* Service Detail Modal */}
      {selectedService && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Backdrop */}
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-md"
            onClick={() => setSelectedService(null)}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          />

          {/* Modal Content */}
          <motion.div
            className="relative max-w-4xl w-full bg-white rounded-3xl overflow-hidden shadow-2xl max-h-[90vh] overflow-y-auto"
            initial={{ scale: 0.9, y: 50 }}
            animate={{ scale: 1, y: 0 }}
            transition={{ type: "spring", duration: 0.5 }}
          >
            {(() => {
              const service = services.find((s) => s.id === selectedService);
              if (!service) return null;
              const Icon = service.icon;

              return (
                <>
                  {/* Header */}
                  <div className={`relative p-8 md:p-12 bg-gradient-to-br ${service.gradient} text-white`}>
                    <button
                      onClick={() => setSelectedService(null)}
                      className="absolute top-6 right-6 w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors"
                    >
                      <X className="w-6 h-6" />
                    </button>

                    <motion.div
                      className="w-20 h-20 rounded-2xl bg-white/20 backdrop-blur-sm flex items-center justify-center mb-6"
                      animate={{ rotate: [0, 360] }}
                      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                    >
                      <Icon className="w-10 h-10" />
                    </motion.div>

                    <h3 className="text-4xl md:text-5xl font-black mb-4">
                      {service.title}
                    </h3>
                    <p className="text-xl text-white/90">
                      {service.description}
                    </p>
                  </div>

                  {/* Services Grid */}
                  <div className="p-8 md:p-12">
                    <h4 className="text-2xl font-bold text-gray-900 mb-8">
                      What We Offer
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {service.items.map((item, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className={`group p-4 rounded-xl bg-gradient-to-br from-gray-50 to-white border-2 border-gray-100 hover:border-transparent hover:shadow-lg transition-all duration-300 cursor-pointer relative overflow-hidden`}
                          whileHover={{ scale: 1.05 }}
                        >
                          <motion.div
                            className={`absolute inset-0 bg-gradient-to-br ${service.gradient} opacity-0 group-hover:opacity-10 transition-opacity`}
                          />
                          <div className="relative z-10 flex items-center gap-3">
                            <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${service.gradient}`} />
                            <span className="font-semibold text-gray-800 group-hover:text-gray-900">
                              {item}
                            </span>
                          </div>
                        </motion.div>
                      ))}
                    </div>

                    {/* CTA Button */}
                    <motion.button
                      className={`mt-8 w-full py-4 bg-gradient-to-r ${service.gradient} text-white font-bold rounded-xl text-lg shadow-lg`}
                      whileHover={{ scale: 1.02, boxShadow: "0 20px 40px rgba(0,0,0,0.2)" }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => navigate("/contact")}
                    >
                      Get Started with {service.title}
                    </motion.button>
                  </div>
                </>
              );
            })()}
          </motion.div>
        </motion.div>
      )}
    </section>
  );
}