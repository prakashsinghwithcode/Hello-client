import { AboutHero } from "./about/AboutHero";
import { OurStory } from "./about/OurStory";
import { MissionVision } from "./about/MissionVision";
import { WhatMakesUsDifferent } from "./about/WhatMakesUsDifferent";
import { OurProcess } from "./about/OurProcess";
import { TeamCulture } from "./about/TeamCulture";
import { TrustSection } from "./about/TrustSection";
import { FinalCTA } from "./about/FinalCTA";
import { Footer } from "./Footer";
import { StickyConsultationButton } from "./StickyConsultationButton";
import { SmoothScroll } from "./SmoothScroll";
import { PageTransition } from "./PageTransition";

export function AboutPage() {
  return (
    <PageTransition>
      <SmoothScroll>
        <div className="relative overflow-x-hidden bg-white">
          {/* About Hero Section */}
          <AboutHero />

          {/* Our Story Journey */}
          <OurStory />

          {/* Mission & Vision */}
          <MissionVision />

          {/* What Makes Us Different */}
          <WhatMakesUsDifferent />

          {/* Our Process */}
          <OurProcess />

          {/* Team/Culture Section */}
          <TeamCulture />

          {/* Trust Section with Stats */}
          <TrustSection />

          {/* Final CTA */}
          <FinalCTA />

          {/* Footer */}
          <Footer />

          {/* Sticky Consultation Button */}
          <StickyConsultationButton />
        </div>
      </SmoothScroll>
    </PageTransition>
  );
}