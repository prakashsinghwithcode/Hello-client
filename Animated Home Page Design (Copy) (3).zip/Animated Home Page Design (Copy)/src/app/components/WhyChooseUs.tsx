import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import {
  Target,
  Users,
  Clock,
  TrendingUp,
  Shield,
  Sparkles,
  Zap,
} from "lucide-react";

const reasons = [
  {
    icon: Target,
    title: "Result-Driven",
    stat: "300%",
    description: "Average growth in client ROI",
    color: "from-blue-500 to-cyan-500",
  },
  {
    icon: Users,
    title: "Expert Team",
    stat: "50+",
    description: "Dedicated professionals",
    color: "from-purple-500 to-pink-500",
  },
  {
    icon: Clock,
    title: "On-Time Delivery",
    stat: "99%",
    description: "Projects delivered on schedule",
    color: "from-green-500 to-teal-500",
  },
  {
    icon: TrendingUp,
    title: "Proven Results",
    stat: "500+",
    description: "Successful projects completed",
    color: "from-orange-500 to-red-500",
  },
  {
    icon: Shield,
    title: "Quality First",
    stat: "98%",
    description: "Client satisfaction rate",
    color: "from-indigo-500 to-purple-500",
  },
  {
    icon: Sparkles,
    title: "Creative Edge",
    stat: "100+",
    description: "Award-winning designs",
    color: "from-pink-500 to-rose-500",
  },
  {
    icon: Zap,
    title: "Fast Support",
    stat: "24/7",
    description: "Always here to help",
    color: "from-yellow-500 to-orange-500",
  },
];

export function WhyChooseUs() {
  const containerRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"],
  });

  const x = useTransform(scrollYProgress, [0, 1], ["0%", "-50%"]);

  return (
    <section
      ref={containerRef}
      className="relative py-24 overflow-hidden bg-gradient-to-br from-gray-50 to-blue-50"
      style={{ position: 'relative' }}
    >
      {/* Animated Background */}
      <motion.div
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, white 1px, transparent 0)`,
          backgroundSize: "40px 40px",
        }}
        animate={{
          backgroundPosition: ["0px 0px", "40px 40px"],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear",
        }}
      />

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4 px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold rounded-full"
          >
            Why Choose Us
          </motion.div>
          <h2 className="text-5xl md:text-6xl lg:text-7xl font-black mb-6">
            We Deliver
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent">
              Outstanding Results
            </span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">
            Numbers that speak louder than words
          </p>
        </motion.div>

        {/* Reasons Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;

            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <motion.div
                  className="relative h-full p-8 rounded-3xl bg-gradient-to-br from-gray-800/50 to-gray-900/50 backdrop-blur-sm border border-gray-700/50 overflow-hidden group"
                  whileHover={{ y: -10, scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Gradient Glow */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-br ${reason.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
                  />

                  {/* Icon */}
                  <motion.div
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${reason.color} flex items-center justify-center mb-6 relative z-10`}
                    whileHover={{ rotate: 360, scale: 1.1 }}
                    transition={{ duration: 0.6 }}
                  >
                    <Icon className="w-8 h-8 text-white" />
                  </motion.div>

                  {/* Stat */}
                  <motion.div
                    className={`text-5xl font-black mb-3 bg-gradient-to-r ${reason.color} bg-clip-text text-transparent`}
                    initial={{ scale: 0 }}
                    whileInView={{ scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 + 0.3, type: "spring" }}
                  >
                    {reason.stat}
                  </motion.div>

                  {/* Title */}
                  <h3 className="text-xl font-bold text-white mb-2">
                    {reason.title}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-400 text-sm leading-relaxed">
                    {reason.description}
                  </p>

                  {/* Bottom Line */}
                  <motion.div
                    className={`absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r ${reason.color}`}
                    initial={{ scaleX: 0 }}
                    whileInView={{ scaleX: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 + 0.5 }}
                  />
                </motion.div>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mt-20"
        >
          <motion.button
            className="px-10 py-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-lg font-bold rounded-full shadow-2xl"
            whileHover={{ scale: 1.05, boxShadow: "0 20px 60px rgba(79, 70, 229, 0.4)" }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate("/contact")}
          >
            Start Your Success Story
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}