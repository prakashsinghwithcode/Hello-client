import { ServicesHero } from "./services/ServicesHero";
import { ServicesGrid } from "./services/ServicesGrid";
import { Footer } from "./Footer";
import { StickyConsultationButton } from "./StickyConsultationButton";
import { SmoothScroll } from "./SmoothScroll";
import { PageTransition } from "./PageTransition";

export function ServicesPage() {
  return (
    <PageTransition>
      <SmoothScroll>
        <div className="relative overflow-x-hidden bg-white">
          {/* Services Hero */}
          <ServicesHero />

          {/* Services Grid - 8 Main Categories */}
          <ServicesGrid />

          {/* Footer */}
          <Footer />

          {/* Sticky Consultation Button */}
          <StickyConsultationButton />
        </div>
      </SmoothScroll>
    </PageTransition>
  );
}