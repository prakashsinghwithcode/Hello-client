import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { ConsultationProvider } from "@/contexts/ConsultationContext";
import { QuoteProvider } from "@/contexts/QuoteContext";
import { RootLayout } from "./components/RootLayout";
import { HomePage } from "./components/HomePage";
import { AboutPage } from "./components/AboutPage";
import { ServicesPage } from "./components/ServicesPage";
import { ContactPage } from "./components/ContactPage";
import { MarketingService } from "./components/services/MarketingService";
import { WebDevelopmentService } from "./components/services/WebDevelopmentService";
import { AppDevelopmentService } from "./components/services/AppDevelopmentService";
import { MarketingDesignService } from "./components/services/MarketingDesignService";
import { CorporateDesignService } from "./components/services/CorporateDesignService";
import { CatalogueDesignService } from "./components/services/CatalogueDesignService";
import { DigitalTemplatesService } from "./components/services/DigitalTemplatesService";
import { BrandingService } from "./components/services/BrandingService";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "about", element: <AboutPage /> },
      { path: "services", element: <ServicesPage /> },
      { path: "contact", element: <ContactPage /> },
      { path: "services/marketing", element: <MarketingService /> },
      { path: "services/web-development", element: <WebDevelopmentService /> },
      { path: "services/app-development", element: <AppDevelopmentService /> },
      { path: "services/marketing-design", element: <MarketingDesignService /> },
      { path: "services/corporate-design", element: <CorporateDesignService /> },
      { path: "services/catalogue-design", element: <CatalogueDesignService /> },
      { path: "services/digital-templates", element: <DigitalTemplatesService /> },
      { path: "services/branding", element: <BrandingService /> },
    ],
  },
]);

export default function App() {
  return (
    <LanguageProvider>
      <ConsultationProvider>
        <QuoteProvider>
          <RouterProvider router={router} />
        </QuoteProvider>
      </ConsultationProvider>
    </LanguageProvider>
  );
}
